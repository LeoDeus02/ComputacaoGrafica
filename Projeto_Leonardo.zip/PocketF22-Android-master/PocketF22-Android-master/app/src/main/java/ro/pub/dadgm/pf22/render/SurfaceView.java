package ro.pub.dadgm.pf22.render;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.support.annotation.NonNull;
import android.view.MotionEvent;

/**
 * Configura o contexto de desenho do OpenGL ES 2.0
 */
public class SurfaceView extends android.opengl.GLSurfaceView {

	/**
	 * A view atual que precisa ser exibida
	 */
	protected ShaderManager.View currentView = null;
	
	/**
	 * O rederizador GL utilizado para desenhar a cena
	 */
	protected GLRenderer renderer;
	
	
	/**
	 * Construtor SurfaceView
	 */
	public SurfaceView(Context context) {
		super(context);
		
		getHolder().setFormat(PixelFormat.TRANSLUCENT);
		
		// Cria o contexto OpenGL ES 2.0
		setEGLContextClientVersion(2);
		setEGLConfigChooser(8, 8, 8, 8, 16, 0);
		
		// Configura o renderizador para desenhar na GLSurfaceView
		renderer = new GLRenderer();
		setRenderer(renderer);
		setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
	}
	
	/**
	 * Construtor com parametro da view inicial
	 */
	public SurfaceView(Context context, ShaderManager.View initialView) {
		this(context);
		
		setView(initialView);
	}
	
	@Override
	public boolean onTouchEvent(@NonNull MotionEvent e) {
		return currentView != null && currentView.onTouchEvent(e);
	}
	
	/**
	 * Altera a view atual
	 */
	public void setView(ShaderManager.View view) {
		synchronized (this) {
			currentView = view;
		}
		
		queueEvent(new Runnable() {
			@Override
			public void run() {
				renderer.setView(getCurrentView());
			}
		});
	}

	/**
	 * Retorna a view atual
	 */
	public synchronized ShaderManager.View getCurrentView() {
		return currentView;
	}
	
}
