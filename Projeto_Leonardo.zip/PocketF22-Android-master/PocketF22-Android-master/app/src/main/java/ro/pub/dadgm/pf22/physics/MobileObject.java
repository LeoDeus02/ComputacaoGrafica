package ro.pub.dadgm.pf22.physics;

import ro.pub.dadgm.pf22.utils.Point3D;
import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * A Interface que todos os objetos móveis irão precisar ter o Physics simulado precisarão implementar.
 */
public interface MobileObject {
	
	/**
	 * Retorna a posição do objeto
	 */
	public Point3D getPosition();
	
	/**
	 * Retorna o objeto da velocidade do vetor
	 */
	public Vector3D getVelocity();
	
	/**
	 * Retorna a lista de forças que estão atuando sobre o objeto
	 */
	public Force[] getForces();
	
}
