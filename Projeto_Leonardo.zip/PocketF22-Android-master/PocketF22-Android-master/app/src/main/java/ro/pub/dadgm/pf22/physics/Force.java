package ro.pub.dadgm.pf22.physics;

import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * Encapsula a força de Newton.
 */
public class Force {
	
	/**
	 * A massa do objeto.
	 */
	protected float mass;
	
	/**
	 * Armazena a aceleração.
	 */
	protected Vector3D acceleration;
	
	
	/**
	 * Força o construtor da massa e aceleração
	 * 
	 * @param mass massa.
	 * @param acceleration tempo de aceleração.
	 */
	public Force(float mass, Vector3D acceleration) {
		this.mass = mass;
		this.acceleration = acceleration;
	}
	
	/**
	 * Retorna o vetor da força de aceleração
	 * 
	 * @return Aceleração resultante.
	 */
	public Vector3D getAcceleration() {
		return acceleration;
	}
	
	/**
	 * Retorna o valor da força assiciada à massa
	 * 
	 * @return Componente de força da massa
	 */
	public float getMass() {
		return mass;
	}
	
}
