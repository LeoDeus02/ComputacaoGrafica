package ro.pub.dadgm.pf22.render;

import android.support.annotation.NonNull;
import android.view.MotionEvent;

import java.util.HashMap;
import java.util.Map;

/**
 *Gerencia uma coleção de programas de sombreadores que são usados ​​para desenhar a cena.
 */
public class ShaderManager {
	
	/**
	 * Mapa de sombreadores disponíveis
	 */
	protected Map<String, Shader> shaderMap;
	
	
	/**
	 * Constrói uma nova instancia ShaderManager
	 */
	public ShaderManager() {
		shaderMap = new HashMap<>();
	}
	
	/**
	 * Inicializa e registra o sombreador dos recursos especificados do Android
	 */
	public void registerShader(String name, int vertexResource, int fragmentResource) {
		Shader shader = new Shader(vertexResource, fragmentResource);
		
		shaderMap.put(name, shader);
	}
	
	/**
	 * Retorna o sombreador com o nome especificado
	 */
	public Shader getShader(String name) {
		return shaderMap.get(name);
	}
	
	/**
	 * Notifica todos os programas sombreadores que o objeto da camera mudou.
	 */
	public void notifyCameraChanged(Camera camera) {
		for (Shader shader: shaderMap.values()) {
			shader.setCamera(camera);
		}
	}
	
	/**
	 * Destrói todos os sombreadores gerenciados e limpa o cache
	 */
	public void destroy() {
		for (Shader shader: shaderMap.values()) {
			shader.destroy();
		}
		clear();
	}
	
	/**
	 *Limpa o estado interno do objeto.
	 */
	public void clear() {
		shaderMap.clear();
	}

	/**
     * Views são classes que representam as cenas OpenGL reais
     */
    public static interface View {

        /**
         * Chamado quando a view é ativada
         */
        public void onActivate();

        /**
         * Chamado antes de um view ser fechada ou quando outra view precisa ser renderizada
         */
        public void onClose();

        /**
         * Chamado quando um frame precisa ser desenhado
         */
        public void draw();

        /**
         * Chamado quando uma view precisa ser redimensionada
         */
        public void onResize(int width, int height);

        /**
         * Recebe o evento do touchscreen.
         */
        public boolean onTouchEvent(@NonNull MotionEvent e);

    }
}
