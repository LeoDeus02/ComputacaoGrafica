package ro.pub.dadgm.pf22.physics;

/**
 * Defines the interface for physics simulation event listeners.
 */
public interface PhysicsSimulationListener {
	
	/**
	 * Chamado depois que a posição de um objeto é alterada
	 * 
	 * Utilizado para validar se o objeto está dentro a área demilitada	 *
	 */
	public void onObjectPositionChange(MobileObject object);
	
	/**
	 * Notifica o listener de que uma colisão entre dois objetos foi detectada
	 * 
	 * @param obj1 Primeiro objeto.
	 * @param obj2 Segundo objeto.
	 */
	public void onCollisionDetected(CollisionObject obj1, CollisionObject obj2);
	
}
