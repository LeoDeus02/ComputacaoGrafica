package ro.pub.dadgm.pf22.render;

import android.opengl.Matrix;

/**
 * aRMAZENA AS INFORMAÇÕES DA CAMERA 3d
 */
public class Camera {
	
	/**
	 * View que define a posção e orienteção da camera
	 */
	protected float[] viewMatrix = new float[16];
	
	/**
	 * Matriz de projeção que traduz o mundo 3D em uma projeção 2D
	 */
	protected float[] projectionMatrix = new float[16];
	
	/**
	 * matriz reversa view*projeção
	 */
	protected float[] reverseMatrix = new float[16];
	
	/**
	 * Armazena a largura e comprimentoda tela para determinar se exibe em retrato ou paisagem
	 */
	protected float viewportRatio;

	/**
	 * Dimensões (px)
	 */
	protected float[] viewportDims = new float[2];
	
	
	/**
	 * Construtor padrão.
	 */
	public Camera() {
		Matrix.setIdentityM(viewMatrix, 0);
		Matrix.setIdentityM(projectionMatrix, 0);
		computeReverseMatrix();
	}
	
	/**
	 * Construtor com as matrizes de projeção e view predefinidas
	 */
	public Camera(float[] viewMatrix, float[] projectionMatrix) {
		setViewMatrix(viewMatrix);
		setProjectionMatrix(projectionMatrix);
		computeReverseMatrix();
	}
	

	/**
	 *Coordenadas na camera no mundo do jogo
	 *
	 * @param x Coordenada X projetada
	 * @param y Coordenada Y projetada
	 * Retorna as coordeadas do mundo do ponto requisitado (x, y, z).
	 */
	public float[] unProjectCoordinates(float x, float y) {
		// Constrói o vetor de inserção
		float[] inVec = new float[] {
				/* x: */ x, /* y: */ y, 
				/* z: */ 0, /* w: */ 1
		};
		// mapa das coordenadas da janela
		inVec[0] = (inVec[0] / viewportDims[0]) * 2.0f - 1.0f;
		inVec[1] = (inVec[1] / viewportDims[1]) * 2.0f - 1.0f;
		inVec[1] = -inVec[1];
		
		// pega as coordenadas de saida
		float[] outVec = new float[4];
		Matrix.multiplyMV(outVec, 0, reverseMatrix, 0, inVec, 0);
		if (outVec[3] == 0) 
			return null;
		
		// Divide entre as coordenadas
		outVec[0] /= outVec[3];
		outVec[1] /= outVec[3];
		outVec[2] /= outVec[3];
		
		return outVec;
	}

	/**
	 * Computa a matriz view*projétil e a armazena no campo #reverseMatrix.
	 */
	public void computeReverseMatrix() {
		float[] tmpMatrix = new float[16];
		Matrix.multiplyMM(tmpMatrix, 0, viewMatrix, 0, projectionMatrix, 0);
		Matrix.invertM(reverseMatrix, 0, tmpMatrix, 0);
	}
	

	public float[] computeNormalMatrix(float[] modelMatrix) {
		float[] tmpMatrix = new float[16];
		float[] tmp2Matrix = new float[16];
		Matrix.multiplyMM(tmpMatrix, 0, viewMatrix, 0, modelMatrix, 0);
		Matrix.invertM(tmp2Matrix, 0, tmpMatrix, 0);
		Matrix.transposeM(tmpMatrix, 0, tmp2Matrix, 0);
		
		return tmpMatrix;
	}
	
	// getters / setters
	
	/**
	 * Retorna a view da matriz GL
	 */
	public float[] getViewMatrix() {
		return viewMatrix;
	}
	
	/**
	 * Configura a matrix da view da camera
	 */
	public void setViewMatrix(float[] viewMatrix) {
		if (viewMatrix.length != 16) 
			throw new IllegalArgumentException("Invalid view matrix specified!");
		
		System.arraycopy(this.viewMatrix, 0, viewMatrix, 0, viewMatrix.length);
		computeReverseMatrix();
	}
	
	/**
	 * Retorna a matriz da projeção da camera
	 */
	public float[] getProjectionMatrix() {
		return projectionMatrix;
	}
	
	/**
	 * Configura a matriz de projeção da camera
	 */
	public void setProjectionMatrix(float[] projectionMatrix) {
		if (projectionMatrix.length != 16)
			throw new IllegalArgumentException("Invalid projection matrix specified!");
		
		System.arraycopy(this.projectionMatrix, 0, projectionMatrix, 0, projectionMatrix.length);
		computeReverseMatrix();
	}
	
	/**
	 * Retorna a viewport atual
	 */
	public float getViewportRatio() {
		return viewportRatio;
	}

	/**
	 * Configura as dimensões da viewport
	 */
	public void setViewportDims(float width, float height) {
		this.viewportDims[0] = width;
		this.viewportDims[1] = height;
		this.viewportRatio = width / height;
	}
	
}
