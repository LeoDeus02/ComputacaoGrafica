package ro.pub.dadgm.pf22.render.objects.hud;

import android.opengl.GLES20;
import android.opengl.Matrix;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.utils.BufferUtils;

/**
 *Desenha uma imagem de sobreposição de menu semitransparente
 */
public class MenuOverlay extends HUDObject {
	
	/**
	 * Triangulos dos objetos
	 */
	protected static final float[] staticVertexArray = {
		0f, 1f, 0, // superior esquerdo
		0f, 0f, 0, // inferior esquerdo
		1f, 0f, 0, // inferior direito
		1f, 1f, 0  // superior direito
	};
	
	/**
	 * Triangulos dos objetos (Matriz de indices do vertex
	 */
	protected static final short[] staticIndexArray = {
		0, 1, 2, 0, 2, 3 // 2 triangulos que formam um quadrado
	};
	
	/**
	 * Cor estática semitransparente para a sobreposição.
	 */
	protected static final float[] staticColor = {
		0.0f, 0.0f, 0.0f, 0.7f
	};
	
	
	/**
	 * Inicializa o objeto do fundo de menu
	 */
	public MenuOverlay(Scene3D scene, String tag, int priority) {
		super(scene, tag, priority);
		
		// carrega o programa GLSL
		shader = scene.getShaderManager().getShader("simple_color");
		
		// inicializa a geometria dos objetos
		vertexBuffer = BufferUtils.asBuffer(staticVertexArray);
		vertexIndexBuffer = BufferUtils.asBuffer(staticIndexArray);
	}
	
	
	@Override
	public void draw() {
		if (!visibility) return;
		
		// atualiza a matriz model dos objetos
		Matrix.setIdentityM(modelMatrix, 0);
		Matrix.translateM(modelMatrix, 0, position.getX(), position.getY(), position.getZ());
		Matrix.scaleM(modelMatrix, 0, width, height, 1);
		
		shader.use();
		
		// pega a localização dos atributos de sombreamento
		int a_position = shader.getAttribLocation("a_position");
		
		// pega a localização dos uniformes de sombreamento
		int u_modelMatrix = shader.getUniformLocation("u_modelMatrix");
		int u_color = shader.getUniformLocation("u_color");
		
		// envia as matrizes
		GLES20.glUniformMatrix4fv(u_modelMatrix, 1, false, modelMatrix, 0);
		
		// envia a informação do vertex para o sombreamento
		GLES20.glEnableVertexAttribArray(a_position);
		GLES20.glVertexAttribPointer(a_position, 3 /* coords */, GLES20.GL_FLOAT, false, 
				3 * 4 /* bytes */, vertexBuffer);
		
		// envia as informações de cor
		GLES20.glUniform4fv(u_color, 1, staticColor, 0);
		
		// Desenha!
		GLES20.glDrawElements(GLES20.GL_TRIANGLES, staticIndexArray.length, GLES20.GL_UNSIGNED_SHORT, vertexIndexBuffer);
	}
	
}
