package ro.pub.dadgm.pf22.activity;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ro.pub.dadgm.pf22.R;
import ro.pub.dadgm.pf22.activity.controllers.GameSceneController;
import ro.pub.dadgm.pf22.activity.controllers.MainMenuController;
import ro.pub.dadgm.pf22.game.Game;
import ro.pub.dadgm.pf22.render.SurfaceView;

public class MainActivity extends Activity {
	
	/**
	 *
	 Armazena os controladores associados às diferentes cenas/views do jogo.
	 */
	private Map<String, Controller> controllers = new HashMap<>();
	
	/**
	 * Renderizador GL a ser utilizado para exibir a tela do jogo.
	 */
	private SurfaceView surfaceView;
	
	/**
	 * Campo utilizado para armazenar o contexto da atividade atual
	 */
	private static Context appContext = null;
	
	/**
	 * Armazena o objeto Game que controla o jogo.
	 */
	private Game game;
	
	/**
	 * Armazena uma lista dos sensorListeners registrados atualmente.
	 */
	private List<SensorEventListener> sensorListeners = new ArrayList<>();
	
	/**
	 * Armazena o objeto do gerenciador de sensores do sistema.
	 */
	private SensorManager sensorManager;
	
	/**
	 * Armazena a instancia do sensor de gravidade.
	 */
	private Sensor gravitySensor;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		super.onCreate(savedInstanceState);
		
		appContext = getApplicationContext();
		
		Log.d(MainActivity.class.getSimpleName(), "Initializing activity...");
		
		// inicializa os objetos do jogo
		game = null;
		if (savedInstanceState != null) {
			game = (Game) savedInstanceState.getSerializable("gameObj");
			Log.d(MainActivity.class.getSimpleName(), "Loaded saved Game object.");
		}
		if (game == null)
			game = new Game();
		
		game.injectActivity(this);
		
		// inicializa os sensores
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		
		// Constrói os objetos do controlador
		MainMenuController mainMenu = new MainMenuController(this);
		GameSceneController gameScene = new GameSceneController(this);
		
		controllers.put("main_menu", mainMenu);
		controllers.put("game_scene", gameScene);
		
		// inicializa a surfaceView
		surfaceView = new SurfaceView(this, null);
		setContentView(surfaceView);
		
		// Ativa o jogo
		switch (game.getStatus()) {
			case STOPPED: // exibir o menu principal
				Log.d(MainActivity.class.getSimpleName(), "Game status before activity was stopped: stopped.");
				mainMenu.activate();
				break;
			
			case RUNNING:
				Log.d(MainActivity.class.getSimpleName(), "Game status before activity was stopped: running.");
				gameScene.activate();
				break;
			case PAUSED: //
				Log.d(MainActivity.class.getSimpleName(), "Game status before activity was stopped: paused.");
				gameScene.activate();
				break;
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		for (SensorEventListener listener: sensorListeners) {
			sensorManager.unregisterListener(listener);
		}
		
		Log.d(MainActivity.class.getSimpleName(), "Activity paused.");
		surfaceView.onPause();
	}
	
	@Override
	protected void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
		// serialize the Game model
		savedInstanceState.putSerializable("gameObject", game);
		Log.d(MainActivity.class.getSimpleName(), "Activity instance saved.");
		super.onSaveInstanceState(savedInstanceState);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		
		for (SensorEventListener listener: sensorListeners) {
			sensorManager.registerListener(listener, gravitySensor, SensorManager.SENSOR_DELAY_GAME);
		}
		
		Log.d(MainActivity.class.getSimpleName(), "Activity resumed.");
		surfaceView.onResume();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.menu_main, menu);
		return false;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();

		if (id == R.id.action_settings) {
			return true;
		}
		
		return super.onOptionsItemSelected(item);
	}
	
	/**
	 * Registra um sensorListener para os eventos de gravidade.
	 */
	public void registerGravitySensorListener(SensorEventListener listener) {
		sensorListeners.add(listener);
		sensorManager.registerListener(listener, gravitySensor, SensorManager.SENSOR_DELAY_NORMAL);
	}
	
	/**
	 * Retorna a referencia à SurfaceView .
	 * 
	 * Uma referência ao objeto da view da surface OpenGL.
	 */
	public SurfaceView getSurfaceView() {
		return surfaceView;
	}
	
	/**
	 * Retorna o controlador nomeado.

	 */
	public Controller getController(String name) {
		return controllers.get(name);
	}
	
	/**
	 * Retorna os objetos da model Game atual.
	 */
	public Game getGame() {
		return game;
	}
	
	/**
	 * Retorna o contexto da aplicação.
	 */
	public static Context getAppContext() {
		return appContext;
	}
	
}
