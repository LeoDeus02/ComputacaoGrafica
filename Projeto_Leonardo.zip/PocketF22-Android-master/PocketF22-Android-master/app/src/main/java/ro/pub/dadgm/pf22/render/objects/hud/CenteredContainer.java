package ro.pub.dadgm.pf22.render.objects.hud;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.objects.ObjectsManager;

/**
 *Componente HUD desenhavel que contem outros componentes (Utiliza Composite pattern)
 */
public class CenteredContainer extends HUDObject {
	
	/**
	 * Lista de objetos "filho" para gerenciar
	 */
	protected ObjectsManager<HUDObject> objects;
	
	
	/**
	 * Iicializa o objetoInitializes the object.
	 * 
	 * @param scene objeto da scene pai
	 * @param tag Tag opcional.
	 * @param priority prioridade opcional
	 */
	public CenteredContainer(Scene3D scene, String tag, int priority) {
		super(scene, tag, priority);
		
		// inicializa o gereciador de objetos
		objects = new ObjectsManager<>();
	}
	
	
	/**
	 * Recalcula o novo posicionamento dos objetos
	 * 
	 * Deve ser chamado quando as dimensões da cena forem modificadas ou quando este objeto for reposicionado
	 */
	public void repositionObjects() {
		for (HUDObject object: objects) {
			// centraliza o objeto
			float[] dims = object.getDimensions();
			object.position().setX( position.getX() + (width / 2) - (dims[0] / 2) );
			object.updateBoundingBox();
		}
	}

	@Override
	public void draw() {
		if (!visibility) return;
		
		// desenha os objeots "filho"
		objects.drawAll();
	}
	
	@Override
	public void setDimensions(float width, float height) {
		super.setDimensions(width, height);
		repositionObjects();
	}
	
	@Override
	public void destroy() {
		for (HUDObject object: objects) {
			object.destroy();
		}
	}
	
	
	// getters / setters
	
	/**
	 * Da acesso ao container ObjectsManager para adicionar/remover e localizar objetos
	 */
	public ObjectsManager<HUDObject> getObjects() {
		return objects;
	}
	
}
