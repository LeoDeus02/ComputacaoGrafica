package ro.pub.dadgm.pf22.game;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import ro.pub.dadgm.pf22.game.models.Plane;

/**
 * Implementa a animação de controles dos aviões.
 */
public class SmoothControlThread extends Thread {
	
	/**
	 * Encapsula os parâmetros de controle animado do avião.
	 */
	public static class PlaneControlParameters {
		
		/**
		 * Comando direcional.
		 */
		protected float yaw = 0;
		
		/**
		 * Comando de controle.
		 */
		protected float pitch;
		
		/**
		 * Constrói um novo objeto com os parâmetros de controle especificados.
		 */
		public PlaneControlParameters(float yaw, float pitch) {
			this.yaw = yaw;
			this.pitch = pitch;
		}
		
	}
	
	/**
	 * Nivel de controle, em milisegundos
	 */
	public final static int PLANE_CONTROL_STEP = 30; // milisegundos
	
	/**
	 * O controle para executar por loop da thread
	 */
	public final static float PLANE_PITCH_DELTA = 1.0f; //
	public final static float PLANE_YAW_DELTA = 2.0f; //
	
	
	/**
	 * Armazena caso a thread de animação estiver pausada.
	 */
	protected boolean paused;
	
	/**
	 * O ultimo momentoem que os objetos foram animados.
	 */
	protected long lastTime;
	
	/**
	 * Tempo deccorido desde que a thread foi pausada.
	 */
	protected long pausedTimeElapsed;
	
	/**
	 * Armazena os parametros de controle animados para aviões específicos
	 */
	protected final IdentityHashMap<Plane, PlaneControlParameters> planeCommands;
	
	
	/**
	 * Inicializa a thread de controle suave do avião
	 */
	public SmoothControlThread() {
		this.planeCommands = new IdentityHashMap<>();
		
		this.paused = false;
	}
	
	/**
	 * Enfilera o comando de controle especificado para o avião..
	 */
	public void queueCommand(Plane plane, PlaneControlParameters parameters) {
		synchronized (planeCommands) {
			// replace all existing parameters for the current plane 
			planeCommands.put(plane, parameters);
		}
	}
	
	/**
	 * O loop principal da thread.
	 */
	@Override
	public void run() {
		// Captura a hora do sistema
		lastTime = System.nanoTime();
		
		// loop de simulação
		while (!isInterrupted()) {
			float td;
			
			if (paused) {
				try {
					Thread.sleep(PLANE_CONTROL_STEP);
					
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
					break;
				}
				continue;
			}
			// Calcula a diferença de tempo
			long now = System.nanoTime();
			td = ((now - lastTime) / 1000000l) / PLANE_CONTROL_STEP;
			lastTime = now;
			
			// Realiza os passos
			synchronized (planeCommands) {
				List<Plane> cleanUpItems = new ArrayList<>(); 
				for (Map.Entry<Plane, PlaneControlParameters> entry: planeCommands.entrySet()) {
					Plane plane = entry.getKey();
					PlaneControlParameters parameters = entry.getValue();
					boolean cleanup = true;
					
					if (parameters.yaw > 0.0001 || parameters.yaw < -0.0001) {
						float diff = Math.signum(parameters.yaw) * td * PLANE_YAW_DELTA;
						if (Math.abs(diff) >= Math.abs(parameters.yaw))
							diff = parameters.yaw;
						plane.steer(diff);
						parameters.yaw -= diff;

						plane.setRoll(parameters.yaw * -2);
						cleanup = false;
					}
					if (parameters.pitch > 0.0001 || parameters.pitch < -0.0001) {
						float diff = Math.signum(parameters.pitch) * td * PLANE_PITCH_DELTA;
						if (Math.abs(diff) >= Math.abs(parameters.pitch))
							diff = parameters.pitch;
						plane.pitch(diff);
						parameters.pitch -= diff;
						cleanup = false;
					}
					
					if (cleanup)
						cleanUpItems.add(plane);
				}
				
				for (Plane plane: cleanUpItems)
					planeCommands.remove(plane);
			}
			
			// aguarda e repete
			try {
				sleep(PLANE_CONTROL_STEP, 0);
				
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
	}
	
	/**
	 * Para a thread de controle etodo o seu processamento (Quando o jogo é pausado, por exemplo).
	 *
	 * Pode ser resumida com o método #resumeProcessing
	 */
	public void pauseProcessing() {
		paused = true;
		pausedTimeElapsed = System.nanoTime() - lastTime;
	}
	
	/**
	 * Resume os controles de processamento
	 */
	public void resumeProcessing() {
		paused = false;
		lastTime = System.nanoTime() - pausedTimeElapsed;
	}
	
}
