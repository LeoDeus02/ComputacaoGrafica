package ro.pub.dadgm.pf22.game.models;

import android.opengl.Matrix;

/**
 * Define um avião inimigo (IA).
 */
public class EnemyPlane extends Plane {
	
	
	/**
	 * Construtor do objeto.
	 */
	public EnemyPlane() {
		// Configurado para o avião aparecer em uma direção aleatória com a velocidade "5"
		steer((float)Math.random()*360);
		setSpeed(4f);
	}
	
	
	// getters / setters
	
}
