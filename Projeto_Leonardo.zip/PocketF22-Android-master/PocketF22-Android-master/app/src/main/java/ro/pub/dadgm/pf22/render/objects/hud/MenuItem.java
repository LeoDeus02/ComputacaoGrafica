package ro.pub.dadgm.pf22.render.objects.hud;

import android.support.annotation.NonNull;
import android.view.MotionEvent;
import android.view.View;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.utils.DrawText;

/**
 * Desenha o item do menu
 */
public class MenuItem extends HUDObject {
	
	/**
	 * Cor estática para diferenciar a textura da fonte
	 */
	protected static final float[] staticColor = {
		0.5f, 0.5f, 1.0f, 1.0f
	};

	/**
	 * Cor dos itens do menu
	 */
	protected static final float[] hoverColor = {
			0.1f, 1.0f, 1.0f, 1.0f
	};
	
	/**
	 * Instancia da scen Drawtext
	 */
	protected DrawText drawText;

	protected boolean hovered = false;

	protected String caption;
	
	/**
	 * Limite do listener OnClick para o item atual
	 */
	protected View.OnClickListener clickListener;
	
	
	/**
	 * Inicializa o objeto menu item
	 */
	public MenuItem(Scene3D scene, String tag, int priority, String caption, View.OnClickListener clickListener) {
		super(scene, tag, priority);
		
		this.drawText = scene.getDrawText();
		this.clickListener = clickListener;
		
		// Altura fixa
		height = 0.7f;
		
		setCaption(caption);
	}
	
	@Override
	public void draw() {
		if (!visibility) return;
		
		prepareDrawText();
		
		synchronized (this) { // hover is set from the Activity thread
			if (hovered) {
				drawText.setColor(hoverColor);
			} else {
				drawText.setColor(staticColor);
			}
		}
		
		drawText.drawText(caption);
	}
	
	@Override
	public boolean onTouchEvent(@NonNull MotionEvent e) {
		if (clickListener == null) return false;
		
		if (e.getAction() == MotionEvent.ACTION_HOVER_ENTER || 
				e.getAction() == MotionEvent.ACTION_HOVER_MOVE) {
			synchronized (this) {
				hovered = true;
			}
			return true;
		}
		
		if (e.getAction() == MotionEvent.ACTION_HOVER_EXIT) {
			synchronized (this) {
				hovered = false;
			}
			return true;
		}
		
		if (e.getAction() == MotionEvent.ACTION_UP) {
			synchronized (this) {
				hovered = false;
			}
			clickListener.onClick(null);
			return true;
		}
		
		return false;
	}
	
	/**
	 * Altera a legenda no item menu
	 */
	public void setCaption(String caption) {
		this.caption = caption;
		
		prepareDrawText();
		width = drawText.calculateDrawWidth(caption) * drawText.getModelScale();
	}
	
	/**
	 * Prepara a instancia Drawtext para desenhar o texto
	 */
	protected void prepareDrawText() {
		float fHeight = height * 0.8f;
		
		drawText.reset();
		drawText.useFont("fonts/Roboto-Regular.ttf", 48);
		
		drawText.setStartPosition(position.getX() + width / 2, position.getY(), position.getZ());
		drawText.setScale(fHeight);
		drawText.setAlignment(DrawText.FontAlign.ALIGN_CENTER);
	}
	
}
