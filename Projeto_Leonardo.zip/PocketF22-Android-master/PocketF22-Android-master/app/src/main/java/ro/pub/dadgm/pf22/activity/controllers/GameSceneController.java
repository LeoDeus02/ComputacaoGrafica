package ro.pub.dadgm.pf22.activity.controllers;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.view.View;

import java.util.HashMap;

import ro.pub.dadgm.pf22.activity.Controller;
import ro.pub.dadgm.pf22.activity.MainActivity;
import ro.pub.dadgm.pf22.game.Game;
import ro.pub.dadgm.pf22.game.SmoothControlThread;
import ro.pub.dadgm.pf22.game.models.Projectile;
import ro.pub.dadgm.pf22.render.ShaderManager;
import ro.pub.dadgm.pf22.render.views.GameScene;

/**
 * Controlador da Game scene.
 */
public class GameSceneController implements Controller {
	
	/**
	 * Referência à activity main.
	 */
	protected final MainActivity mainActivity;
	
	/**
	 * Referência ao objeto da view MainMenu.
	 */
	protected final GameScene view;
	
	/**
	 * Lista das ações possíves.
	 */
	protected final HashMap<String, View.OnClickListener> actions;
	
	/**
	 * Objeto Game.
	 */
	protected final Game game;
	
	/**
	 * Construtor do objeto controlador.
	 */
	public GameSceneController(final MainActivity mainActivity) {
		this.mainActivity = mainActivity;
		this.view = new GameScene(this);
		this.game = mainActivity.getGame();
		
		actions = new HashMap<>();
		
		// popula as ações
		actions.put("hud_pause", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.pause();
			}
		});
		
		actions.put("hud_steer_left", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.queuePlaneCommand(game.getWorld().getPlayer(), new SmoothControlThread.PlaneControlParameters(+15, 0));
			}
		});
		actions.put("hud_steer_right", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.queuePlaneCommand(game.getWorld().getPlayer(), new SmoothControlThread.PlaneControlParameters(-15, 0));
			}
		});
		actions.put("hud_pitch_up", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.queuePlaneCommand(game.getWorld().getPlayer(), new SmoothControlThread.PlaneControlParameters(0, -5));
			}
		});
		actions.put("hud_pitch_down", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.queuePlaneCommand(game.getWorld().getPlayer(), new SmoothControlThread.PlaneControlParameters(0, +5));
			}
		});
		
		actions.put("hud_shoot_missile", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.shootProjectile(game.getWorld().getPlayer(), Projectile.ProjectileType.PROJECTILE_ROCKET);
			}
		});

		actions.put("menu_resume", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.start(); // resume game
			}
		});


		actions.put("menu_exit", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.stop();
				mainActivity.getController("main_menu").activate();
			}
		});

		mainActivity.registerGravitySensorListener(new GravityListener());
	}
	
	/**
	 * O lISTENER de eventos da gravidade (baseado em acelerômetro).
	 */
	protected class GravityListener implements SensorEventListener {
		
		@Override
		public void onSensorChanged(SensorEvent event) {
			//Log.d(GameSceneController.class.getSimpleName(), "Sensor event: " + 
			//		event.values[0] + ", " + event.values[1] + ", " + event.values[2] );
		}
		
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// nothing to do
		}
	}
	
	@Override
	public synchronized View.OnClickListener getAction(String actionName) {
		if (actions.containsKey(actionName)) 
			return actions.get(actionName);
		return null;
	}
	
	@Override
	public ShaderManager.View getView() {
		return view;
	}
	
	@Override
	public void activate() {
		mainActivity.getSurfaceView().setView(view);
	}
	
	@Override
	public void queueEvent(Runnable worker) {
		mainActivity.getSurfaceView().queueEvent(worker);
	}
	
	
	// getters / setters
	
	/**
	 * Retorna a referência para o objeto Game model.
	 */
	public Game getGame() {
		return game;
	}
	
}
