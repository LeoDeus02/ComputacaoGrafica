package ro.pub.dadgm.pf22.game.models;

import java.util.Stack;

import ro.pub.dadgm.pf22.physics.CollisionObject;

/**
 * Classe modelo para o terreno.
 */
public class Terrain extends BaseModel implements CollisionObject {

	/**
	 * Numero de iterações do desenho para algoritmo com falha
	 */
	public final int GEN_ITERATIONS = 20;
	
	/**
	 * Possíveis valores de deslocamento de altura.
	 */
	public final float GEN_DISPLACEMENT_MIN = 0.5f;
	public final float GEN_DISPLACEMENT_SCALE = 1.0f;

	/**
	 * Nível de detalhe para o algoritmo fractal
	 */
	public final int FRACTAL_LOD = 8;
	
	
	/**
	 * Descreve todos os tipos de terrenos possíveis.
	 */
	public final static Object[][] TERRAIN_TYPES = {
			// { nome, texture_file, altura inicial, altura final }
			{ "grama", "grass.jpg", 0.0f, World.WORLD_MAX_HEIGHT / 3f },
			{ "neve", "snow.jpg", World.WORLD_MAX_HEIGHT / 2.5f, World.WORLD_MAX_HEIGHT },
			{ "montanha", "mountain.png", World.WORLD_MAX_HEIGHT / 2.5f, World.WORLD_MAX_HEIGHT },
	};
	
	/**
	 * Dimensões das unidades do mundo.
	 */
	public final static float UNIT_SCALE = 10f;
	
	
	// atributos do terreno
	
	/**
	 * Armazena as dimensões (comprimento e larggura) do mapa.
	 */
	protected int[] dimensions;
	
	/**
	 * Altura máxima.
	 */
	protected float maxHeight;
	
	/**
	 * Armazena a dimensão do mapa.
	 * 
	 * O array é primeiro indexado por X e então por Y
	 */
	protected float[][] heightMap;
	
	/**
	 * Cada ponto do terreno possui um tipo diferente de terreno
	 */
	protected byte[][] typeMap;
	
	/**
	 *Armazena a contagem de pontos para cada tipo de terreno gerado
	 */
	protected int[] typeCount;
	
	
	/**
	 * Construtor do objeto.
	 * 
	 * @param wx largura do terreo (X).
	 * @param wy comprimento do terreno (Y).
	 * @param maxHeight Altura máxima a ser gerada.
	 */
	public Terrain(int wx, int wy, float maxHeight) {
		this.dimensions = new int[] { wx, wy };
		this.maxHeight = maxHeight;
		
		heightMap = new float[wx][wy];
		typeMap = new byte[wx][wy];
		typeCount = new int[TERRAIN_TYPES.length];
		
		// generateMap();
		generateFractalMap();
		generateTypeMap();
	}
	
	/**
	 * Gera o terreno utilizando o algoritmo: <a href="http://www.javaworld.com/article/2076745">Diamond-Square Algorithm</a>.
	 */
	private void generateFractalMap() {
		final float roughness = 0.6f;
		final int lod = FRACTAL_LOD;
		
		int divisions = 1 << lod;
		
		float[][] terrain = new float[divisions + 1][divisions + 1];
		
		terrain[0][0] = rnd();
		terrain[0][divisions] = rnd();
		terrain[divisions][divisions] = rnd();
		terrain[divisions][0] = rnd();
		
		float rough = roughness;
		for (int i = 0; i < lod; ++ i) {
			int r = 1 << (lod - i), s = r >> 1;
			for (int j = 0; j < divisions; j += r)
				for (int k = 0; k < divisions; k += r)
					diamond(terrain, j, k, r, rough);
			if (s > 0)
				for (int j = 0; j <= divisions; j += s)
					for (int k = (j + s) % r; k <= divisions; k += r)
						square (terrain, j - s, k - s, r, rough, divisions);
			
			rough *= roughness;
		}
		
		// gera a altura do terreno utilizando o terreno fractal
		float min = 0;
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				float tx = (i / (float)dimensions[0]) * divisions;
				float ty = (j / (float)dimensions[1]) * divisions;

				float s00 = terrain[(int)Math.floor(tx)][(int)Math.floor(ty)];
				float s01 = terrain[(int)Math.floor(tx)][(int)Math.ceil(ty)];
				float s10 = terrain[(int)Math.ceil(tx)][(int)Math.floor(ty)];
				float s11 = terrain[(int)Math.ceil(tx)][(int)Math.ceil(ty)];
				
				float xfrac = tx - (int)tx;
				float yfrac = ty - (int)ty;
				float tval = (1 - yfrac) * ( (1 - xfrac)*s00 + xfrac*s01) +
						yfrac * ( (1 - xfrac)*s10 + xfrac*s11);
				
				heightMap[i][j] = tval * this.maxHeight;
				
				min = Math.min(heightMap[i][j], min);
			}
		}
		
		// Nivela o mapa
		float minLevel = (float)Math.random() * min*0.5f;
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				heightMap[i][j] = heightMap[i][j] - minLevel;
			}
		}
		

		// calcula a altura maxima gerada
		maxHeight = 0;
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				if (maxHeight < heightMap[i][j])
					maxHeight = heightMap[i][j];
			}
		}
	}

	/**
	 * Gera um diamante no terreno.
	 * 
	 * @param terrain O terreno alvo.
	 * @param x Coordenada X do diamante.
	 * @param y coordenada Y.
	 * @param side Tamanho do diamante.
	 * @param scale Escala do diamante.
	 */
	private void diamond (float[][] terrain, int x, int y, int side, float scale) {
		if (side > 1) {
			int half = side / 2;
			float avg = (terrain[x][y] + terrain[x + side][y] +
					terrain[x + side][y + side] + terrain[x][y + side]) * 0.25f;
			terrain[x + half][y + half] = avg + rnd () * scale;
		}
	}

	/**
	 * Gera um quadrado.
	 *
	 * @param terrain O terreno alvo.
	 * @param x Coordenada X do quadrado.
	 * @param y coordenada Y.
	 * @param side Tamanho do quadrado.
	 * @param scale Tamando do diamante.
	 * @param divisions Matriz de numero de divisões.
	 */

	private void square (float[][] terrain, int x, int y, int side, float scale, int divisions) {
		int half = side / 2;
		float avg = 0.0f, sum = 0.0f;
		
		if (x >= 0) {
			avg += terrain[x][y + half]; sum += 1.0;
		}
		if (y >= 0) {
			avg += terrain[x + half][y]; sum += 1.0;
		}
		if (x + side <= divisions) {
			avg += terrain[x + side][y + half]; sum += 1.0;
		}
		if (y + side <= divisions) {
			avg += terrain[x + half][y + side]; sum += 1.0;
		}
		
		terrain[x + half][y + half] = avg / sum + rnd () * scale;
	}

	private float rnd () {
		return (float)(2.0 * Math.random() - 1.0);
	}

	/**
	 * Gera o terreno do mapa utilizando o método: <a href="http://www.lighthouse3d.com/opengl/terrain/index.php3?fault">Fault Algorithm</a>.
	 */
	private void generateFaultMap() {
		// fill the height map with maxHeight / 2
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				heightMap[i][j] = maxHeight / 2.0f;
			}
		}
		
		// Iteração do algoritmo
		for (int k=0; k<GEN_ITERATIONS; k++) {
			// generate a line
			double v = Math.random() * 2 * Math.PI;
			double a = Math.sin(v);
			double b = Math.cos(v);
			double d = Math.sqrt(dimensions[0] * dimensions[0] + dimensions[1] * dimensions[1]);
			double c = Math.random() * d - d / 2.0;
			
			for (int i = 0; i < dimensions[0]; i++) {
				for (int j = 0; j < dimensions[1]; j++) {
					float displacement = (float) Math.random() * GEN_DISPLACEMENT_SCALE +
							GEN_DISPLACEMENT_MIN;
					if ((a * i + b * j) > c) {
						heightMap[i][j] += displacement;
					} else {
						heightMap[i][j] -= displacement;
					}
				}
			}
		}
		// normaliza o mapa
		float min = 0;
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				min = Math.min(heightMap[i][j], min);
			}
		}
		
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				heightMap[i][j] -= min;
				if (heightMap[i][j] < 0)
					heightMap[i][j] = 0;
				else if (heightMap[i][j] > maxHeight) {
					heightMap[i][j] = maxHeight;
				}
			}
		}
		
		// Aplica o  Gaussian Blur na altura do mapa para suavizá-lo
		float[][] kernel = makeGaussianKernel(11, 30);
		heightMap = convolutionFilter(heightMap, kernel, 1, 0, maxHeight);
	}

	/**
	 * Applies a convolution filter to the specified heightMap.
	 * 
	 * @param heightMap The height map to convolute.
	 * @param filterMatrix The convolution kernel to use.
	 * @param factor Convolution factor.
	 * @param bias Bias value.
	 * @param maxHeight The maximum value to clamp.
	 * @return The convoluted height map.
	 */
	public static float[][] convolutionFilter(float[][] heightMap, float[][] filterMatrix, 
											  float factor, int bias, float maxHeight) {
		
		int height = heightMap.length;
		int width = heightMap[0].length;
		
		float[][] resultMap = new float[height][width];
		
		float value;
		
		int filterWidth = filterMatrix[0].length;
		// int filterHeight = filterMatrix.length;
		int filterOffset = (filterWidth-1) / 2;
		
		for (int offsetY = filterOffset; offsetY < height - filterOffset; offsetY++) {
			for (int offsetX = filterOffset; offsetX < width - filterOffset; offsetX++) {
				value = 0;
				
				for (int filterY = -filterOffset; filterY <= filterOffset; filterY++) {
					for (int filterX = -filterOffset; filterX <= filterOffset; filterX++) {
						value += heightMap[offsetY][offsetX] *
								filterMatrix[filterY + filterOffset][filterX + filterOffset];
					}
				}
				
				value = factor * value + bias;
				value = (value > maxHeight ? maxHeight : (value < 0 ? 0 : value));
				
				resultMap[offsetY][offsetX] = value;
			}
		}
		
		return resultMap;
	}
	

	protected static float[][] makeGaussianKernel(int length, float weight) {
		float[][] kernel = new float[length][length];
		float sumTotal = 0;
		
		int kernelRadius = length / 2;
		float distance;
		
		float calculatedEuler = (float)(1.0 /
				(2.0 * Math.PI * Math.pow(weight, 2)));
		
		for (int filterY = -kernelRadius; filterY <= kernelRadius; filterY++) {
			for (int filterX = -kernelRadius; filterX <= kernelRadius; filterX++) {
				distance = ((filterX * filterX) +
						(filterY * filterY)) /
						(2 * (weight * weight));
				
				kernel[filterY + kernelRadius][filterX + kernelRadius] =
						calculatedEuler * (float)Math.exp(-distance);
				
				sumTotal += kernel[filterY + kernelRadius][filterX + kernelRadius];
			}
		}
		
		for (int y = 0; y < length; y++) {
			for (int x = 0; x < length; x++) {
				kernel[y][x] = kernel[y][x] * (1.0f / sumTotal);
			}
		}
		
		return kernel;
	}
	
	/**
	 * Gera os tipos de terreno para cada ponto da altura do mapa
	 * 
	 * <p>The algorithm is the following: 
	 * <ul>
	 *     <li>a random type is extracted from {@link #TERRAIN_TYPES};</li>
	 *     <li>if it doesn't meet the constraints, it has a 5% probability of passing;</li>
	 *     <li>otherwise, the probability of selection is 50%;</li>
	 *     <li>on success, there is a 50% probability of a neighbor to also be populated with the 
	 *     same type;</li>
	 *     <li>repeat until all points on the map are populated.</li>
	 * </ul>
	 * </p>
	 */
	private void generateTypeMap() {
		// use a stack for doing the floodfill
		Stack<int[]> stack = new Stack<>();
		
		// initialization
		for (int i=0; i<dimensions[0]; i++) {
			for (int j = 0; j < dimensions[1]; j++) {
				typeMap[i][j] = -1; // uninitialized
				stack.add(new int[]{ i, j });
			}
		}
		
		// Processa todos os pontos
		while (!stack.isEmpty()) {
			int[] d = stack.pop();
			int i = d[0];
			int j = d[1];
			if (typeMap[i][j] >= 0)
				continue;
			
			float h = heightMap[i][j];
			// byte t = (byte)(Math.random() * TERRAIN_TYPES.length);
			byte t = 0;
			
			boolean passed = dice(0.05); // 5% chance to pass anyways
			if (!passed) {
				// extrai o tipo de terreno
				Float min = (Float)TERRAIN_TYPES[t][2];
				Float max = (Float)TERRAIN_TYPES[t][3];
				if (min < h && h < max) {
					passed = dice(0.9); // 90% probability to pass
				}
			}
			
			if (passed) {
				typeMap[i][j] = t;
				typeCount[t]++;
				
				// 50% chance to fill to a neighbor
				// 4 neighbors
				if (i>0 && dice(0.8)) { typeMap[i - 1][j] = t; typeCount[t]++; }
				if (j>0 && dice(0.8)) { typeMap[i][j-1] = t; typeCount[t]++; }
				if (i<dimensions[0]-1 && dice(0.8)) { typeMap[i+1][j] = t; typeCount[t]++; }
				if (j<dimensions[1]-1 && dice(0.8)) { typeMap[i][j+1] = t; typeCount[t]++; }
				
			} else {
				// reprocess
				stack.add(d);
			}
		}
	}
	
	/**
	 * Rolls a 2-sided dice (boolean :D ) with the specified chance.
	 * 
	 * @param chance The chance to return true.
	 * @return Returns true or false, depending on the roll.
	 */
	private boolean dice(double chance) {
		double r = Math.random();
		return (0.5 - chance/2) <= r && r <= (0.5 + chance/2);
	}
	
	
	// getters / setters
	
	/**
	 * Returns the height map matrix's dimensions.
	 * 
	 * @return The map matrix dimensions as a 2-element array (width, length).
	 */
	public synchronized int[] getMatrixDimensions() {
		return new int[] { dimensions[0], dimensions[1] };
	}
	
	/**
	 * Returns the height map's real (scaled) dimensions.
	 *
	 * @return The map's real dimensions as a 2-element array (width, length).
	 */
	public synchronized float[] getDimensions() {
		return new float[] { dimensions[0] * UNIT_SCALE, dimensions[1] * UNIT_SCALE };
	}
	
	/**
	 * Returns the generated height map (unscaled).
	 * 
	 * <p>The map should not be modified!</p>
	 * 
	 * @return The generated height map.
	 */
	public synchronized float[][] getHeightMap() {
		return heightMap;
	}
	
	/**
	 * Returns the generated terrain type map.
	 * 
	 * <p>The map should not be modified!</p>
	 * 
	 * @return The generated type map.
	 */
	public synchronized byte[][] getTypeMap() {
		return typeMap;
	}
	
	/**
	 * Returns the area count for each terrain type.
	 * 
	 * <p>The array should not be modified!</p>
	 * 
	 * @return The type count map.
	 */
	@SuppressWarnings("unused")
	public synchronized int[] getTypeCount() {
		return typeCount;
	}
	
	/**
	 * Returns the guaranteed maximum height of a point on the terrain.
	 * 
	 * @return The maximum height of a generated point.
	 */
	public synchronized float getMaxHeight() {
		return maxHeight;
	}
	
	/**
	 * Returns the specified point's height.
	 * 
	 * @param x The X coordinate of the point (world units / scaled).
	 * @param y The Y coordinate of the point (world units / scaled).
	 * @return Height map's value at the specified point (after scaling).
	 */
	public synchronized float getHeightAt(float x, float y) {
		int i = (int)(x / UNIT_SCALE);
		int j = (int)(y / UNIT_SCALE);
		
		return heightMap[i][j];
	}
	
	
	@Override
	public boolean collidesWith(CollisionObject obj) {
		if (obj instanceof BaseMobileModel) {
			BaseMobileModel mobileObj = (BaseMobileModel)obj;
			
			// get the elevation at the specified position
			float[] position = mobileObj.getPosition().toArray();
			if (position[0] < 0 || position[1] < 0 || 
					position[0] >= dimensions[0]*UNIT_SCALE || position[1] >= dimensions[1]*UNIT_SCALE) {
				// out of bounds, so it can't collide
				return false;
			}
			
			float height = getHeightAt(position[0], position[1]);
			if (position[2] <= height) {
				return true;
			}
		}
		
		return false;
	}
	
}
