package ro.pub.dadgm.pf22.activity;

import ro.pub.dadgm.pf22.render.ShaderManager;

/**
 *
 * Define a interface do controlador de cena que vincula uma view e os Models
 * O controlador geralmente recebe eventos da interação do usuário e chama os métodos apropriados nos objetos Model e na view para realizar as aões necessárias
 *
 * O objeto View recebe alguns dos eventos e os dispacha para o objeto UI apontado e então o controlador é solicitado a fazer uma ação específica usando o método (@Link #getAction)
 *
 * Todos os métodos devem ser chamados da thread Activity
 */
public interface Controller {
	
	/**
	 * Retorna o objeto executável de ação indicada.
	 *
	 *
	 */
	public android.view.View.OnClickListener getAction(String actionName);
	
	/**
	 * Retorna oobjeto da view utilizado para renderizar a cena.
	 */
	public ShaderManager.View getView();
	
	/**
	 * Alterna para a view gerenciada do controlador.
	 * 
	 * Isso irá solicitar à Activity pai para encerrar a view atual e tornar os controladores como ativos
	 *
	 */
	public void activate();

	/**
	 * Coloca na fila um evento a ser executado na thread GL.
	 */
	public void queueEvent(Runnable worker);
	
}
