package ro.pub.dadgm.pf22.game.models;

import android.opengl.Matrix;

import ro.pub.dadgm.pf22.physics.CollisionObject;
import ro.pub.dadgm.pf22.utils.BoundingBox3D;
import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * Classe model básica para os aviões de combate (Jogador e inimigos).
  */
public class Plane extends BaseMobileModel {
	

	/**
	 * Vida padrão do avião.
	 */
	public final float PLANE_HEALTH = 100;
	
	/**
	 * Comprimento do avião (de trás até a frente).
	 */
	public final float PLANE_LENGTH = 19 / 19.0f;
	
	/**
	 * Largura do avião (de uma asa até a outra).
	 */
	public final float PLANE_WIDTH = 13 / 19.0f;
	
	/**
	 * Altura do avião.
	 */
	public final float PLANE_HEIGHT = 4 / 19.0f;
	
	/**
	 * Movimentação do avião (Lateral).
	 */
	protected float roll;
	
	/**
	 * Movimentação do avião (vertical).
	 */
	protected float pitch;
	
	/**
	 * Direcionamento do avião para o chão.
	 */
	protected float yaw;
	
	/**
	 * Velocidade do avião
	 */
	protected float speed;
	
	/**
	 * Saúde do aviãoCurrent plane health.
	 */
	protected float health;
	
	
	/**
	 * Construtor Model do objeto constructor.
	 */
	public Plane() {
		roll = 0;
		pitch = 0;
		yaw = 0;
		speed = 5.0f;
		
		// Saúde máxima ao iniciar
		health = PLANE_HEALTH;
	}
	
	/**
	 * Alterar o angulo de movimentação.
	 */
	public void steer(float angle) {
		yaw = (yaw + angle) % 360;
	}

	/**
	 * Movimenta o avião para cima ou para baixo (Valores negativos para "baixo")
	 */
	public void pitch(float angle) {
		setPitch(pitch + angle);
	}
	
	// getters / setters
	
	/**
	 * Retorna a saúde do avião
	 */
	public synchronized float getHealth() {
		return health;
	}
	
	/**
	 * retorna o movimento do avião
	 */
	public synchronized float getRoll() {
		return roll;
	}
	
	/**
	 * Retorna o movimento (vertical) do avião
	 */

	public synchronized float getPitch() {
		return pitch;
	}
	
	/**
	 * Configura o movimento do avião para um valor absoluto.
	 */
	public synchronized void setPitch(float angle) {
		if (angle > 45) angle = 45;
		if (angle < -45) angle = -45;
		this.pitch = angle;
	}
	
	/**
	 * Configura o movimento (horizontal) do avião para um valor absoluto.
	 */

	public synchronized void setRoll(float angle) {
		if (angle > 90) angle = 90;
		if (angle < -90) angle = -90;
		this.roll = angle;
	}
	
	/**
	 * Retorna o movimento do avião (vertical).
	 */
	public synchronized float getYaw() {
		return yaw;
	}

	/**
	 * Retorna a velocidade do avião.
	 */
	public synchronized float getSpeed() {
		return speed;
	}
	
	/**
	 * Altera a velocidade do avião
	 */
	public void setSpeed(float speed) {
		this.speed = speed;
	}
	
	
	/**
	 * Calcula a velocidade atual do avião.
	 */
	@Override
	public synchronized Vector3D getVelocity() {
		float[] tmpMatrix = new float[16];
		Matrix.setIdentityM(tmpMatrix, 0);
		Matrix.rotateM(tmpMatrix, 0, yaw, 0, 0, 1f);
		Matrix.rotateM(tmpMatrix, 0, pitch, 0, 1, 0);
		
		float[] velocityArr = new float[]{ speed, 0, 0, 0 };
		float[] direction = new float[4];
		Matrix.multiplyMV(direction, 0, tmpMatrix, 0, velocityArr, 0);
		
		velocity.setValues(direction[0], direction[1], direction[2]);
		
		return velocity;
	}
	
	
	/**
	 * Retorna a caixa limitadora do plano
	 */
	public BoundingBox3D getBoundingBox() {
		return new BoundingBox3D(position, new float[]{ PLANE_LENGTH, PLANE_WIDTH, PLANE_HEIGHT });
	}
	
	@Override
	public boolean collidesWith(CollisionObject obj) {
		if (obj instanceof Plane) {
			Plane planeObj = (Plane)obj;
			return this.getBoundingBox().intersects(planeObj.getBoundingBox());
			
		} else if (obj instanceof Terrain) {

			return obj.collidesWith(this);
			
		} else if (obj instanceof Projectile) {
			Projectile projectileObj = (Projectile)obj;
			return this.getBoundingBox().intersects(projectileObj.getBoundingBox());
		}
		
		return false;
	}
	
}
