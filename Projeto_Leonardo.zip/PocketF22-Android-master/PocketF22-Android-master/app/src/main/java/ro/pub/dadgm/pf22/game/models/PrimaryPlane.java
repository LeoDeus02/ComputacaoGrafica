package ro.pub.dadgm.pf22.game.models;

import android.opengl.Matrix;

/**
 * Define o avião controlado pelo jogador.
 */
public class PrimaryPlane extends Plane {
	
	
	/**
	 * Construtor do objeto.
	 */
	public PrimaryPlane() {
		// Configura o avião em uma direção aleatoria com a velocidade "5"
		steer((float)Math.random()*360);
		setSpeed(5f);
	}
	
	
	// getters / setters
	
}
