package ro.pub.dadgm.pf22.game.models;

import java.io.Serializable;

/**
 * Classe model comum para todos os objetos do jogo.
 */
public abstract class BaseModel implements Serializable {
	
	/**
	 * Construtor padrão
	 */
	protected BaseModel() {
	}
	
}
