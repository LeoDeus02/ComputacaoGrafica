package ro.pub.dadgm.pf22.render.objects;

import android.opengl.Matrix;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.Shader;

/**
 * O AbstractObject3D fornece uma implementação abstrata, mas flexível, de um objeto 3D desenhável
 */
public abstract class AbstractObject3D implements Object3D {
	
	/**
	 * tag dos objetos.
	 */
	protected final String tag;
	
	/**
	 * Prioridade dos objetos
	 */
	protected final int priority;
	
	/**
	 * A scene que gerencia este objeto
	 */
	protected Scene3D scene;
	
	/**
	 * Armazena a matrix model dos objetos
	 */
	protected float[] modelMatrix = new float[16];
	
	/**
	 * O programa de sombreamento para desenhar
	 */
	protected Shader shader;
	
	/**
	 * Buffer utilizado para armazenar os vertices dos objetos
	 */
	protected FloatBuffer vertexBuffer;
	
	/**
	 * Buffer com os indices do vertex que formam triangulos
	 */
	protected ShortBuffer vertexIndexBuffer;
	
	
	/**
	 * Construtor padrão
	 */
	protected AbstractObject3D(Scene3D scene) {
		this.scene = scene;
		this.tag = null;
		this.priority = 0;
		Matrix.setIdentityM(modelMatrix, 0);
	}
	
	/**
	 * Construtor com tag e prioridade prioritária
	 * 
	 * @param scene Objeto da scene pai
	 * @param tag tag do objeto
	 * @param priority Prioridade do objeto
	 */
	protected AbstractObject3D(Scene3D scene, String tag, int priority) {
		this.scene = scene;
		this.tag = tag;
		this.priority = priority;
		Matrix.setIdentityM(modelMatrix, 0);
	}
	
	@Override
	public String getTag() {
		return tag;
	}
	
	@Override
	public int getPriority() {
		return priority;
	}
	
	@Override
	public void destroy() {
		
	}
	
}
