package ro.pub.dadgm.pf22.game;

import android.util.Log;

import java.io.Serializable;
import java.util.Collection;

import ro.pub.dadgm.pf22.activity.MainActivity;
import ro.pub.dadgm.pf22.game.models.*;
import ro.pub.dadgm.pf22.physics.CollisionObject;
import ro.pub.dadgm.pf22.physics.MobileObject;
import ro.pub.dadgm.pf22.physics.PhysicsSimulationListener;
import ro.pub.dadgm.pf22.physics.PhysicsThread;
import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * Gerencia o jogo e reforça as regras.
 * 
 * O jogo deve ser iniciado chamando o método #start e pode ser encerrado chamando o método #stop
 */
public class Game implements Serializable {
	
	/**
	 * Define o estados possíveis do jogo.
	 */
	public static enum GameStatus {
		STOPPED,
		RUNNING,
		PAUSED
	}
	
	/**
	 * Niveis de dificuldade do jogo (IA).
	 */
	public static enum Difficulty {
		FACIL,
		NORMAL,
		DIFICIL
	}

	/**
	 * Número de aviões por nível de dificuldade.
	 */
	public static final int NUM_PLANES_FACIL = 10,
			NUM_PLANES_NORMAL = 20,
			NUM_PLANES_DIFICIL = 30;
	
	/**
	 * Identifica se o jogo foi parado ou em pausa
	 */
	protected GameStatus status;
	
	/**
	 * Mundo do jogo.
	 */
	protected World world;
	
	/**
	 * Dificuldade do jogo.
	 */
	protected Difficulty difficulty;
	
	/**
	 * Status do som (Ligado/desligado).
	 */
	protected boolean sound;
	
	/**
	 * Pontuação.
	 */
	protected float score;
	
	/**
	 * Activity principal.
	 */
	protected transient MainActivity activity;
	
	/**
	 * A thread de simulação do modulo physics.
	 */
	protected transient PhysicsThread physicsThread;
	
	/**
	 * A thread para controlar o avião suavemente.
	 */
	protected transient SmoothControlThread smoothControl;
	
	
	/**
	 * Construtor do jogo.
	 * 
	 * Inicia um jogo do zero
	 */
	public Game() {
		status = GameStatus.STOPPED;
		sound = true;
		
		difficulty = Difficulty.NORMAL;
	}
	
	
	/**
	 * Injeta a dependência da activity pai na instancia atual do jogo.
	 * 
	 * Deve ser chamado antes de qualquer coisa (especialmente do start)
	 */
	public void injectActivity(MainActivity activity) {
		this.activity = activity;
	}
	
	/**
	 * Inicia e remove o jogo do pause.
	 */
	public synchronized void start() {
		if (status == GameStatus.RUNNING)
			return;
		
		if (status == GameStatus.PAUSED) {
			initializeTransientObjects();
			
			// Acorda as threads e continua
			if (physicsThread.isAlive()) {
				physicsThread.resumeProcessing();
			} else {

				physicsThread.start();
			}
			
			if (smoothControl.isAlive()) {
				smoothControl.resumeProcessing();
			} else {

				smoothControl.start();
			}
			
			status = GameStatus.RUNNING;
			return;
		}
		
		// inicia o mundo do jogo
		world = new World();
		
		Terrain terrain = world.getTerrain();
		
		// Configura a posição inicial do jogador em um ponto alatório
		PrimaryPlane player = world.getPlayer();
		player.getPosition().setCoordinates(
				(float) Math.random() * (World.WORLD_WIDTH_X / 2) + World.WORLD_WIDTH_X / 4,
				(float) Math.random() * (World.WORLD_WIDTH_Y / 2) + World.WORLD_WIDTH_Y / 4,
				terrain.getMaxHeight() + 2f );
		
		// Gera os aviões inimigos
		int numEnemyPlanes = NUM_PLANES_FACIL;
		switch (difficulty) {
			case NORMAL: numEnemyPlanes = NUM_PLANES_NORMAL; break;
			case DIFICIL: numEnemyPlanes = NUM_PLANES_DIFICIL; break;
		}
		
		for (int i=0; i<numEnemyPlanes; i++) {
			EnemyPlane enemy = new EnemyPlane();
			boolean firstPos = true;
			
			while (firstPos || checkCollisions(enemy, world.getCollidableObjects())) {
				firstPos = false;
				enemy.getPosition().setCoordinates(
						(float) Math.random() * (World.WORLD_WIDTH_X / 2) + World.WORLD_WIDTH_X / 4,
						(float) Math.random() * (World.WORLD_WIDTH_Y / 2) + World.WORLD_WIDTH_Y / 4,
						terrain.getMaxHeight() + (float)Math.random()*5 + 1f);
				enemy.steer((float)Math.random()*360);
			}
			
			world.addPlane(enemy);
		}
		
		initializeTransientObjects();
		
		// Jogo iniciado!
		physicsThread.start();
		smoothControl.start();
		
		status = GameStatus.RUNNING;
	}
	
	
	/**
	 * Verifica os objetos para colisões.
	 *
	 * Retona True caso o objeto colida, caso contrário será false.
	 */
	protected boolean checkCollisions(CollisionObject object, Collection<CollisionObject> collection) {
		for (CollisionObject object2: collection) {
			if (object.collidesWith(object2))
				return true;
		}
		return false;
	}
	
	/**
	 * [Re]Inicializa os objetos transitórios
	 */
	protected void initializeTransientObjects() {

		if (physicsThread == null)
			physicsThread = new PhysicsThread(world.getMobileObjects(), world.getCollidableObjects(), new PhysicsListener());
		
		if (smoothControl == null)
			smoothControl = new SmoothControlThread();
		
		// AQUI AINDA PRECISARIA INICIAR O MÓDULO DE IA
	}
	
	/**
	 * PARA o jogo, desalocando todos os recursos utilizados (As threads de simulação, por exemplo).
	 */
	public synchronized void stop() {
		if (status == GameStatus.STOPPED)
			return;
		
		// Interrompe as Threads
		physicsThread.interrupt();
		smoothControl.interrupt();
		
		try {
			physicsThread.join();
			smoothControl.join();
			
		} catch (InterruptedException e) {
			Log.e(Game.class.getSimpleName(), "Thread interrupted!", e);
		}
		
		physicsThread = null;
		smoothControl = null;
		world = null;
		
		status = GameStatus.STOPPED;
	}
	
	/**
	 * Pausa o Jogo.
	 */
	public synchronized void pause() {
		if (status != GameStatus.RUNNING)
			return;
		
		physicsThread.pauseProcessing();
		smoothControl.pauseProcessing();
		
		status = GameStatus.PAUSED;
	}
	
	/**
	 * Executa uma tarefa na Activity thread.
	 */
	public void runHandler(Runnable task) {
		activity.runOnUiThread(task);
	}
	
	
	// getters / setters
	
	/**
	 * Retorna a pontuação atual ou ultima pontuação do jogo.
	 * 
	 * @return Pontuação atual do jogo.
	 */
	public float getScore() {
		return score;
	}
	
	/**
	 * Returna o status do jogo (executando / parado / pausado).
	 * 
	 * @return Status do jogo.
	 */
	public GameStatus getStatus() {
		return status;
	}
	
	/**
	 * Retorna o status do som do jogo.
	 */
	public boolean getSound() {
		return sound;
	}
	
	/**
	 * Toggles game sound status.
	 * 
	 * @param status The new status to set.
	 */
	public void setSound(boolean status) {
		sound = status;
	}
	
	/**
	 * Retorna a dificuldade atual do jogo.
	 */
	public Difficulty getDifficulty() {
		return difficulty;
	}
	
	/**
	 * Altera a dificuldade do jogo.
	 */
	public void setDifficulty(Difficulty difficulty) {
		if (status != GameStatus.STOPPED)
			return;
		
		this.difficulty = difficulty;
	}
	
	/**
	 * Retorna a referência do mundo atual do jogo.
	 * 
	 * Retorna null se o jogo não estiver iniciado!
	 */
	public World getWorld() {
		return world;
	}
	
	/**
	 * Enfilera o comando recebido do controle do avião.
	 */
	public void queuePlaneCommand(Plane plane, SmoothControlThread.PlaneControlParameters parameters) {
		smoothControl.queueCommand(plane, parameters);
	}
	
	/**
	 * Atira o projétil do avião.
	 * 
	 * O projétil herda o vetor de frente do plano
	 */
	public void shootProjectile(Plane plane, Projectile.ProjectileType projectileType) {
		Projectile projectile = new Projectile(projectileType);
		Vector3D velocity = new Vector3D(plane.getVelocity());
		Vector3D position = new Vector3D(plane.getPosition());
		
		velocity.normalize();

		position.add(velocity);
		
		velocity.normalize();
		velocity.multiply(10f); // velocidade do projétil
		
		projectile.getPosition().setCoordinates(position.getX(), position.getY(), position.getZ());
		projectile.getVelocity().setValues(velocity.getX(), velocity.getY(), velocity.getZ());
		
		projectile.setOrientation(plane.getYaw(), plane.getPitch());
		
		world.addProjectile(projectile);
	}
	
	/**
	 * Destrói o avião especificado.
	 */
	protected void destroyObject(Plane plane) {
		if (world == null) return;
		
		if (plane == world.getPlayer()) {
			// Se o avião for o do próprio jogar, o jog finaliza
			stop();
			
		} else if (plane instanceof EnemyPlane) {
			world.removePlane((EnemyPlane)plane);
		}

	}
	
	/**
	 * Destrói o objeto projétil especificado.
	 */
	protected void destroyObject(Projectile projectile) {
		if (world == null) return;
		
		world.removeProjectile(projectile);
	}

	/**
	 * Processa (normalmente deleta) o objeto especificado depois de uma colisão.
	 */
	protected void processCollision(CollisionObject obj) {
		if (obj instanceof Plane) {
			destroyObject((Plane)obj);
			
		} else if (obj instanceof Projectile) {
			destroyObject((Projectile)obj);
			
		}
	}
	
	/**
	 * Implementação do PhysicListener para a instancia atual no jogo.
	 */
	protected class PhysicsListener implements PhysicsSimulationListener {
		
		@Override
		public void onObjectPositionChange(final MobileObject object) {
			runHandler(new Runnable() {
				@Override
				public void run() {
					// Verifica os limites dos objetos
					float[] position = object.getPosition().toArray();
					float[] dimensions = world.getTerrain().getDimensions();
					
					// Ajusta as posições
					if (position[0] < 0 || position[1] < 0 ||
							position[0] >= dimensions[0] || position[1] >= dimensions[1]) {
						if (object instanceof Plane) {
							Plane planeObject = (Plane)object;
							
							// Posicionamento do avião
							if (position[0] < 0) {
								planeObject.getPosition().setX(0.1f);
								planeObject.steer(120);
							}
							if (position[1] < 0) {
								planeObject.getPosition().setY(0.1f);
								planeObject.steer(120);
							}
							if (position[0] >= dimensions[0]) {
								planeObject.getPosition().setX(dimensions[0]-0.1f);
								planeObject.steer(120);
							}
							if (position[1] >= dimensions[1]) {
								planeObject.getPosition().setY(dimensions[1]-0.1f);
								planeObject.steer(120);
							}
							
						} else if (object instanceof Projectile) {
							// destrói/desaparece com o projétil
							destroyObject((Projectile)object);
						}
					}
					
					if (position[2] >= World.WORLD_MAX_HEIGHT) {
						if (object instanceof Plane) {
							// Ajusta a altura do objeto
							object.getPosition().setZ(World.WORLD_MAX_HEIGHT);
							((Plane)object).setPitch(45);
							
						} else if (object instanceof Projectile) {
							// destrói/desaparece com o projétil
							destroyObject((Projectile)object);
						}
					}
				}
			});
		}
		
		@Override
		public void onCollisionDetected(final CollisionObject obj1, final CollisionObject obj2) {
			runHandler(new Runnable() {
				@Override
				public void run() {
					processCollision(obj1);
					processCollision(obj2);
				}
			});
		}
	}
	
}
