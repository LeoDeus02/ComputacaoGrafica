package ro.pub.dadgm.pf22.render.objects.game;

import android.opengl.GLES20;
import android.opengl.Matrix;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.objects.AbstractObject3D;

/**
 * Implementa a caixa do céu OpenGL
 */
public class SkyBox extends AbstractObject3D {
	
	/**
	 * Caminho das models de recursos
	 */
	protected final String TEXTURE_PATH = "textures/cubemap/";

	/**
	 * Textura do mapa
	 */
	protected int texture;
	
	/**
	 * Inicializa o objeto do jato 3D
	 */
	public SkyBox(Scene3D scene, String tag, int priority) {
		super(scene, tag, priority);
		
		// pega o programa de sombras
		shader = scene.getShaderManager().getShader("s3d_tex_phong");
		
		// carrega as texturas
		texture = 0;
	}
	
	@Override
	public void draw() {
		Matrix.setIdentityM(modelMatrix, 0);
		// Matrix.translateM(modelMatrix, 0, 0, 0, 0);
		// Matrix.scaleM(modelMatrix, 0, 0.3f, 0.3f, 0.3f);
		
		shader.use();
		
		// pega a localização dos atributos de sombras
		int a_position = shader.getAttribLocation("a_position");
		int a_textureCoords = shader.getAttribLocation("a_textureCoords");
		
		// pega a localização de uniformes das sombras
		int u_modelMatrix = shader.getUniformLocation("u_modelMatrix");
		
		int u_texture = shader.getUniformLocation("u_texture");
		
		// Envia as matrizes
		GLES20.glUniformMatrix4fv(u_modelMatrix, 1, false, modelMatrix, 0);
		
		// Envia os dados vertex para o sombreamento
		GLES20.glEnableVertexAttribArray(a_position);
		GLES20.glVertexAttribPointer(a_position, 3 /* coords */, GLES20.GL_FLOAT, false,
				3 * 4 /* bytes */, vertexBuffer);
		
		GLES20.glEnableVertexAttribArray(a_textureCoords);
		GLES20.glVertexAttribPointer(a_textureCoords, 2, GLES20.GL_FLOAT, false,
				0, vertexBuffer);
		
		GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
		GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
		GLES20.glUniform1i(u_texture, 0);
		
		// desenha
		GLES20.glDrawElements(GLES20.GL_TRIANGLES, /*AJUSTAR: */0, GLES20.GL_UNSIGNED_SHORT, vertexIndexBuffer);
	}
	
}
