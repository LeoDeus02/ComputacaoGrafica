package ro.pub.dadgm.pf22.render.objects.hud;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.utils.Point3D;

/**
 * Gerencia ,ultiplos itens do menu e calcula seu posicionamento automaticamente
 */
public class MenuContainer extends CenteredContainer {
	
	/**
	 * Inicializa o objeto do fundo do menu
	 * 
	 * @param scene Objeto da scene pai
	 * @param tag tag opcional.
	 * @param priority prioridade opcional.
	 */
	public MenuContainer(Scene3D scene, String tag, int priority) {
		super(scene, tag, priority);
	}
	
	
	/**
	 * Recalcula o novo osicionamento dos itens de menu
	 */
	@Override
	public void repositionObjects() {
		final float itemHeight = 0.7f;
		final float itemSpacing = 0.1f;
		
		float curY = position.getY() + height - itemHeight;
		
		// computa a posição Y dos itens do menu em ordem.
		for (HUDObject object: objects) {
			Point3D position = object.position();
			position.setY(curY);
			object.updateBoundingBox();
			
			curY -= itemHeight + itemSpacing;
		}
		
		// centraliza os objetos
		super.repositionObjects();
	}

	@Override
	public void draw() {
		if (!visibility) return;
		
		// Desenha todos os objetos "filho"
		objects.drawAll();
	}
	
	@Override
	public void destroy() {
		for (HUDObject object: objects) {
			object.destroy();
		}
	}
	
}
