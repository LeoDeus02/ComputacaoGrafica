package ro.pub.dadgm.pf22.game.models;

import ro.pub.dadgm.pf22.physics.CollisionObject;
import ro.pub.dadgm.pf22.utils.BoundingBox3D;

/**
 * Classe base para todos os projéteis.
 */
public class Projectile extends BaseMobileModel {

	/**
	 * Define as dimensões da colisão do projétil
	 */
	public final static float PROJECTILE_DIMS = 0.1f;
	
	/**
	 * Define os tipos possíveis de projéteis
	 */
	public static enum ProjectileType {
		PROJECTILE_ROCKET, 
		PROJECTILE_BULLETS
	}
	
	
	/**
	 * Tipo de projétil.
	 */
	protected ProjectileType type;

	/**
	 * Orientação do projétil
	 */
	protected float yaw = 0, pitch = 0;
	
	/**
	 * Construtor do objeto
	 */
	public Projectile(ProjectileType type) {
		this.type = type;
	}
	
	
	/**
	 * Retorna a caixa delimitadora do plano..
	 */
	public BoundingBox3D getBoundingBox() {
		return new BoundingBox3D(position, new float[]{ PROJECTILE_DIMS, PROJECTILE_DIMS, PROJECTILE_DIMS });
	}

	/**
	 * Configura o angulo de orientação do projétil.
	 */
	public void setOrientation(float yaw, float pitch) {
		this.yaw = yaw;
		this.pitch = pitch;
	}
	
	/**
	 * Retorna o angulo (vertical).
	 */
	public float getYaw() {
		return yaw;
	}
	
	/**
	 * Retorna o ângulo (horizontal)tile.
	 */
	public float getPitch() {
		return pitch;
	}
	
	
	@Override
	public boolean collidesWith(CollisionObject obj) {
		if (obj instanceof Plane) {
			Plane planeObj = (Plane)obj;
			return this.getBoundingBox().intersects(planeObj.getBoundingBox());
			
		} else if (obj instanceof Terrain) {
			return obj.collidesWith(this);
			
		} else if (obj instanceof Projectile) {
			Projectile projectileObj = (Projectile)obj;
			return this.getBoundingBox().intersects(projectileObj.getBoundingBox());
		}
		
		return false;
	}
	
	
	// getters / setters
	
	/**
	 * Retona o tipo de projétil.
	 */
	public ProjectileType getType() {
		return type;
	}
	
}
