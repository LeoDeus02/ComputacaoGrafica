package ro.pub.dadgm.pf22.game.models;

import ro.pub.dadgm.pf22.physics.CollisionObject;
import ro.pub.dadgm.pf22.physics.Force;
import ro.pub.dadgm.pf22.physics.MobileObject;
import ro.pub.dadgm.pf22.utils.Point3D;
import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * Classe model utilizada com o physics para atualizar a posição e a velociadade automaticamente e verificar a detecção de colisões..
 */
public abstract class BaseMobileModel extends BaseModel implements MobileObject, CollisionObject {
	
	/**
	 * Posição do objeto.
	 */
	protected Point3D position;
	
	/**
	 * A velocidade do objeto que inicialmente é estática - v = (0, 0, 0,).
	 */
	protected Vector3D velocity;
	
	
	/**
	 * Construtor padrão. Inicializa a posição.
	 */
	protected BaseMobileModel() {
		position = new Point3D();
		velocity = new Vector3D();
	}
	
	
	/**
	 * Por padrão, nenhuma força atua sobre um objeto.
	 */
	@Override
	public Force[] getForces() {
		return new Force[0];
	}
	
	@Override
	public Point3D getPosition() {
		return position;
	}
	
	@Override
	public Vector3D getVelocity() {
		return velocity;
	}
	
}
