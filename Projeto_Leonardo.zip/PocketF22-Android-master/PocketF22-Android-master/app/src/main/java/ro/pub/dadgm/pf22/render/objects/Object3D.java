package ro.pub.dadgm.pf22.render.objects;

/**
 * Representa um objeto 3D renderezável que pode ser desenhado em uma cena
 */
public interface Object3D {
	
	/**
	 * Renderiza o objeto
	 */
	public void draw();
	
	/**
	 * Retorna a tag do objeto
	 */
	public String getTag();
	
	/**
	 * Retorna a prioridade de desenho do objeto.
	 * O primeiro objeto a ser desenhado na tela será o que tiver a menor prioridade.
	 */
	public int getPriority();
	
	/**
	 * Chamado quando o objeto precisa ser destruído
	 */
	public void destroy();
	
}
