package ro.pub.dadgm.pf22.activity.controllers;

import android.view.View;

import java.util.HashMap;

import ro.pub.dadgm.pf22.activity.Controller;
import ro.pub.dadgm.pf22.activity.MainActivity;
import ro.pub.dadgm.pf22.game.Game;
import ro.pub.dadgm.pf22.render.ShaderManager;
import ro.pub.dadgm.pf22.render.views.MainMenu;

/**
 * Controlador da view main menu, Acts as controller for the main menu view, manipulando os eventos de cliques no menu.
 */
public class MainMenuController implements Controller {
	
	/**
	 * Referência à activity principal.
	 */
	protected final MainActivity mainActivity;
	
	/**
	 * Referência ao objeto da view MainMenu.
	 */
	protected final MainMenu view;

	/**
	 * Lista das ações possíveis.
	 */
	protected final HashMap<String, View.OnClickListener> actions;
	
	/**
	 * Objeto Game.
	 */
	protected final Game game;
	
	
	/**
	 * Construtor do objeto controlador.
	 */
	public MainMenuController(final MainActivity mainActivity) {
		this.mainActivity = mainActivity;
		this.view = new MainMenu(this);
		this.game = mainActivity.getGame();
		
		actions = new HashMap<>();
		
		// populando as ações
		actions.put("start_game", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.start();
				mainActivity.getController("game_scene").activate();
			}
		});
		
		actions.put("toggle_difficulty", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (game.getDifficulty()) {
					case FACIL: game.setDifficulty(Game.Difficulty.NORMAL);
						break;
					case NORMAL: game.setDifficulty(Game.Difficulty.DIFICIL);
						break;
					case DIFICIL: game.setDifficulty(Game.Difficulty.FACIL);
						break;
				}
			}
		});
		
		actions.put("toggle_sound", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				game.setSound(!game.getSound());
			}
		});
		
		actions.put("about", new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// xxx
			}
		});
	}
	
	@Override
	public synchronized View.OnClickListener getAction(String actionName) {
		if (actions.containsKey(actionName)) 
			return actions.get(actionName);
		return null;
	}
	
	@Override
	public ShaderManager.View getView() {
		return view;
	}
	
	@Override
	public void activate() {
		mainActivity.getSurfaceView().setView(view);
	}
	
	@Override
	public void queueEvent(Runnable worker) {
		mainActivity.getSurfaceView().queueEvent(worker);
	}
	
	
	// getters / setters
	
	/**
	 * Retorna a referência para o objeto Game model.
	 */
	public Game getGame() {
		return game;
	}
	
}
