package ro.pub.dadgm.pf22.render;

import ro.pub.dadgm.pf22.render.utils.DrawText;

/**
 * Scene3D é a interface de fachada que é utilizada para prover serviços de desenho para objetos "filho" {ShaderManager.View}
 */
public interface Scene3D {
	
	/**
	 *Retorna a câmera atual usada para desenhar a cena.
	 */
	public Camera getCamera();
	
	/**
	 * Permite acesso à instancia das cenas
	 */
	public ShaderManager getShaderManager();

	/**
	 *Fornece acesso à instância da biblioteca de desenho de texto da cena
	 */
	public DrawText getDrawText();
	
}
