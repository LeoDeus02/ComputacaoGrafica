package ro.pub.dadgm.pf22.physics;

import java.util.Set;

import ro.pub.dadgm.pf22.utils.Vector3D;

/**
 * A thread principal da simulação Physics (fisica)

 * Os parametros dos objetos móveis serão atualizados (posição, direção, velocidade);
 * Os objetos que podem colidir serão verificados por colisões
 */
public class PhysicsThread extends Thread {
	
	/**
	 * O período de simulação, em milisegundos.
	 */
	public final int PHYSICS_SIMULATION_PERIOD = 50; // milliseconds
	
	
	/**
	 * A coleção de objetos móveis simulados
	 */
	protected final Set<MobileObject> mobileObjects;
	
	/**
	 * A colação de objetos colisiveis
	 */
	protected final Set<CollisionObject> collidableObjects;
	
	/**
	 * A instancia do listener de simulação que receberá eventos de simulação
	 */
	protected final PhysicsSimulationListener listener;
	
	/**
	 * Armazena se a Thread Physys está pausada
	 */
	protected boolean paused;
	
	/**
	 * Guarda a ultima hora (na hora do aparelho) emq ual objetos foram simulados
	 */
	protected long lastTime;
	
	/**
	 * O tempo que já passou desde que a thread foi pausada
	 */
	protected long pausedTimeElapsed;
	
	
	/**
	 * Inicializa a simulação physics para o conjunto de objetos especificados
	 * 
	 * @param mobileObjects Conjunto de objetos móveis a ser simulados continuosamente
	 * @param collidableObjects Conjunto de objetos colisiveis para verificar por colisões
	 * @param listener A instancia do listener de simulação que irá receber eventos de simulação
	 */
	public PhysicsThread(Set<MobileObject> mobileObjects, Set<CollisionObject> collidableObjects, 
						 PhysicsSimulationListener listener) {
		this.mobileObjects = mobileObjects;
		this.collidableObjects = collidableObjects;
		this.listener = listener;
		this.paused = false;
	}
	
	
	/**
	 * Loop principal da thread
	 */
	@Override
	public void run() {
		// Pega o horário do sistema
		lastTime = System.nanoTime();
		
		// loop de simulação
		while (!isInterrupted()) {
			int td;
			
			if (paused) {
				try {
					Thread.sleep(PHYSICS_SIMULATION_PERIOD);
					
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
					break;
				}
				continue;
			}
			// calcula a diferença de tempo
			long now = System.nanoTime();
			td = (int) ((now - lastTime) / 1000000l);
			lastTime = now;
			
			// primeiramente, simula as equações de movimentos
			MobileObject[] mobileObjectsSnapshot = mobileObjects.toArray(new MobileObject[mobileObjects.size()]);
			for (MobileObject object : mobileObjectsSnapshot) {
				updateObjectVelocity(object, td);
				updateObjectPosition(object, td);
			}
			
			// verifica por colisões
			@SuppressWarnings("unchecked")
			CollisionObject[] collidableObjectsSnapshot = collidableObjects.toArray(new CollisionObject[collidableObjects.size()]);
			for (int i = 0; i < collidableObjectsSnapshot.length; i++) {
				for (int j = i + 1; j < collidableObjectsSnapshot.length; j++) {
					if (collidableObjectsSnapshot[i].collidesWith(collidableObjectsSnapshot[j])) {
						// retorna um evento
						listener.onCollisionDetected(collidableObjectsSnapshot[i], collidableObjectsSnapshot[j]);
					}
				}
			}
			
			// espera e repete
			try {
				sleep(PHYSICS_SIMULATION_PERIOD, 0);
				
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
	}
	
	/**
	 * Pausa a thread Physics etodo o seu processamento (quando o jogo é pausado, por exemplo).
	 */
	public void pauseProcessing() {
		paused = true;
		pausedTimeElapsed = System.nanoTime() - lastTime;
	}
	
	/**
	 * Retoma o processamento da Physics
	 */
	public void resumeProcessing() {
		paused = false;
		lastTime = System.nanoTime() - pausedTimeElapsed;
	}
	
	/**
	 * Calcula a nova posição para um objeto
	 * 
	 * @param object Objeto alvo.
	 * @param td tempo, em millisegundos.
	 */
	protected void updateObjectPosition(MobileObject object, int td) {
		Vector3D position = new Vector3D(object.getPosition());
		Vector3D velocity = object.getVelocity();
		
		float step = td / 1000.f;
		float dx = velocity.getX()*step;
		float dy = velocity.getY()*step;
		float dz = velocity.getZ()*step;
		
		position.add(new Vector3D(dx, dy, dz));
		
		// atualiza a posição
		object.getPosition().setCoordinates(position.getX(), 
				position.getY(), position.getZ());
		
		if (dx != 0 || dy != 0 || dz != 0) 
			listener.onObjectPositionChange(object);
	}
	
	/**
	 * Calcula a nova velocidade de vetor para um objeto
	 */
	protected void updateObjectVelocity(MobileObject object, int td) {
		// pega um snapshot da velocidade do objeto
		float[] velocity = object.getVelocity().toArray();
		float step = td / 1000.f;
		
		// pega as forças agindo sobre o objeto
		Force[] forces = object.getForces();
		for (Force f: forces) {
			float[] acceleration = f.getAcceleration().toArray();
			
			velocity[0] += acceleration[0] * step;
			velocity[1] += acceleration[1] * step;
			velocity[2] += acceleration[2] * step;
		}
		
		// configura a nova velocidade
		object.getVelocity().setValues(velocity[0], velocity[1], velocity[2]);
	}
	
}
