package ro.pub.dadgm.pf22.utils.events;

/**
 * Simples interface listener de evento que permite um objeto saber quando uma coleção é alterada
 */
public interface CollectionListener<T> {
	
	/**
	 * lançado quando um novo objeto foi adicionado à coleção
	 */
	public void onObjectAdded(T object);
	
	/**
	 * lançado quando um novo objeto foi removido da coleção
	 */
	public void onObjectRemoved(T object);
	
}
