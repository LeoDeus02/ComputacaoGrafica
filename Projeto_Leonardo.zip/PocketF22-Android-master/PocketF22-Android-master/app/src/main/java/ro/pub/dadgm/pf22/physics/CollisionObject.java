package ro.pub.dadgm.pf22.physics;

/**
 * Todos os objetos que podem ser colididos com outros objetos devem implementar esta interface
 */
public interface CollisionObject {
	
	/**
	 * testa se o o objeto atual colide com o outro especificado
	 * Todas as implementações devem ser reflexivas (A colide com B <=> B colide com A).
	 * 
	 * @param obj Objeto ao qual será testado a colisão.
	 * @return True caso os dois objetos colidirem, se não, falso.
	 */
	public boolean collidesWith(CollisionObject obj);
	
}
