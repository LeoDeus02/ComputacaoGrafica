package ro.pub.dadgm.pf22.render.objects;

import org.jetbrains.annotations.NotNull;

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TreeMap;

/**
 * Gerencia uma lista de objetos renderizáveis 3D
 */
public class ObjectsManager<O3D extends Object3D> extends AbstractCollection<O3D> {

	protected class ObjectsCollection extends AbstractCollection<O3D> {
		
		/**
		 * Lista de objetos internos
		 */
		protected HashSet<O3D> objects;
		
		/**
		 * Construtor da coleção interna
		 */
		protected ObjectsCollection() {
			this.objects = new HashSet<>();
		}
		
		@Override
		public boolean add(O3D obj) {
			boolean added = objects.add(obj);
			if (!added) return false;

			ObjectsManager.this.objectAdded(obj);
			
			return true;
		}
		
		@Override
		public boolean remove(Object obj) {
			if (!(obj instanceof Object3D))
				throw new ClassCastException("The object must implement Object3D!");
			
			if (!objects.remove(obj)) return false;

			ObjectsManager.this.objectRemoved(((Object3D)obj));
			
			return true;
		}
		
		@Override
		@NotNull
		public Iterator<O3D> iterator() {
			final Iterator<O3D> internalIterator = objects.iterator();
			
			return new Iterator<O3D>() {
				protected O3D current;
				
				@Override
				public boolean hasNext() {
					return internalIterator.hasNext();
				}
				
				@Override
				public O3D next() {
					current = internalIterator.next();
					return current;
				}
				
				@Override
				public void remove() {
					if (current == null)
						throw new IllegalStateException("No current element in iteration!");
					
					// usa a implementação da coleção
					ObjectsCollection.this.remove(current);
				}
			};
		}
		
		@Override
		public boolean contains(Object obj) {
			return objects.contains(obj);
		}
		
		@Override
		public int size() {
			return objects.size();
		}
		
	}
	
	/**
	 * Os objetos são armazenados dentro do mapa
	 */
	protected Map<String, ObjectsCollection> objectsMap;
	
	/**
	 * Mapa interno que retém os objetos agrupados por prioridade
	 */
	protected Map<Integer, Collection<O3D>> priorityMap;
	
	/**
	 * Tamanho da coleção em cache.
	 */
	protected int size = 0;
	
	
	/**
	 * Constrói uma coleção de objetos vazios
	 */
	public ObjectsManager() {
		objectsMap = new HashMap<>();
		priorityMap = new TreeMap<>();
	}
	
	/**
	 *
	 Constrói uma nova instância do gerenciador de objetos com os objetos da coleção fornecida
	 */
	public ObjectsManager(Collection<O3D> collection) {
		this();
		this.addAll(collection);
	}
	
	/**
	 * Desenha todos os objetos na coleção
	 */
	public void drawAll() {
		for (O3D obj: this) {
			obj.draw();
		}
	}
	
	
	/**
	 * Retorna todos os objetos que possuem uma pag especificada
	 */
	public Collection<O3D> getObjectsByTag(String tag) {
		return objectsMap.get(tag);
	}
	
	
	//Implementação da coleção
	
	@Override
	public boolean add(O3D obj) {
		String tag = obj.getTag();
		
		if (!objectsMap.containsKey(tag)) {
			objectsMap.put(tag, this.new ObjectsCollection());
		}
		
		return objectsMap.get(tag).add(obj);
	}
	
	/**
	 * Localiza e remove o objeto especificado
	 */
	@Override
	public boolean remove(Object obj) {
		if (!(obj instanceof Object3D)) 
			throw new ClassCastException("The object must implement Object3D!");
		
		String tag = ((Object3D)obj).getTag();
		return objectsMap.containsKey(tag) && objectsMap.get(tag).remove(obj);
	}
	
	@Override
	@NotNull
	public Iterator<O3D> iterator() {
		final Iterator<Map.Entry<Integer, Collection<O3D>>> mapIter = 
				priorityMap.entrySet().iterator();
		
		/**
		 * Classe iterator para a coleção de gerenciamento dos objetos
		 */
		return new Iterator<O3D>() {
			protected Iterator<O3D> curIter = null;
			protected O3D current;
			
			@Override
			public boolean hasNext() {
				if (curIter == null) {
					if (!mapIter.hasNext()) 
						return false;
					curIter = mapIter.next().getValue().iterator();
				}
				if (curIter.hasNext())
					return true;
				
				while (mapIter.hasNext()) {
					curIter = mapIter.next().getValue().iterator();
					if (curIter.hasNext()) 
						return true;
				}
				
				return false;
			}
			
			@Override
			public O3D next() {
				if (!hasNext())
					throw new NoSuchElementException("hasNext() == false");
				current = curIter.next();
				return current;
			}
			
			@Override
			public void remove() {
				if (current == null)
					throw new IllegalStateException("No current element in iteration!");

				ObjectsManager.this.remove(current);
			}
		};
	}
	
	@Override
	public void clear() {
		objectsMap = new HashMap<>();
		priorityMap = new TreeMap<>();
	}
	
	@Override
	public boolean contains(Object obj) {
		if (!(obj instanceof Object3D))
			throw new ClassCastException("The object must implement Object3D!");
		
		String tag = ((Object3D)obj).getTag();
		return objectsMap.containsKey(tag) && objectsMap.get(tag).contains(obj);
	}
	
	@Override
	public int size() {
		return size;
	}

	/**
	 * Chamado internamente quando um novo objeto é adicionado à coleção
	 */
	protected void objectAdded(O3D obj) {
		// tamanho do incremento
		size++;
		
		Integer priority = obj.getPriority();
		if (!priorityMap.containsKey(priority)) {
			priorityMap.put(priority, new HashSet<O3D>());
		}
		
		priorityMap.get(priority).add(obj);
	}

	/**
	 * Chamado internamento quando um unico objeto é removido da coleção
	 */
	protected void objectRemoved(Object3D obj) {
		// tamanho do decremento
		size--;
		
		// remove do mapa de objetos classificados
		Integer priority = obj.getPriority();
		if (priorityMap.containsKey(priority)) {
			priorityMap.get(priority).remove(obj);
		}
	}
	
}
