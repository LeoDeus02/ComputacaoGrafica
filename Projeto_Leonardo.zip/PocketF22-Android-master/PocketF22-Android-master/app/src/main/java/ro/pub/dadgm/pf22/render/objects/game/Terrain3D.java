package ro.pub.dadgm.pf22.render.objects.game;

import android.opengl.GLES20;
import android.opengl.Matrix;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;

import ro.pub.dadgm.pf22.game.models.Terrain;
import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.objects.AbstractObject3D;
import ro.pub.dadgm.pf22.render.utils.BufferUtils;
import ro.pub.dadgm.pf22.render.utils.NormalUtils;
import ro.pub.dadgm.pf22.render.utils.TextureLoader;
import ro.pub.dadgm.pf22.render.views.GameScene;


/**
 * Desenha o terreno 3D
 */
public class Terrain3D extends AbstractObject3D {
	
	/**
	 * Define o caminho para as texturas do terreno
	 */
	protected final String TEXTURE_PATH = "textures/";
	
	/**
	 * Define um pacote de terreno que tenha uma textura específica.
	 */
	protected class TerrainParcel {
		
		/**
		 * Identificador de tipo do pacote
		 */
		protected byte type;
		
		// work arrays
		
		/**
		 * Armazena as coordenadas da textura
		 */
		protected float[] textureCoords;
		
		/**
		 * Lista de triangulos (indices do vertex)
		 */
		protected ArrayList<Integer> triangles;
		
		/**
		 * Armazena o contador de indices do triangulo
		 */
		protected int indexCount;
		
		/**
		 * Buffer de cordenadas da textura
		 */
		protected int vbo;
		
		/**
		 * Triangulos dos pacotes
		 */
		protected int ibo;
		
		/**
		 *Armazena o recurso de textura carregada para o pacote.
		 */
		protected int texture;
		
		/**
		 * Inicializa um novo pacote
		 */
		public TerrainParcel(byte type) {
			this.type = type;
			
			// initialize the arrays / buffers
			textureCoords = new float[Terrain3D.this.vertexCount * 2];
			triangles = new ArrayList<>();
		}
		
		/**
		 * Adiciona o triangulo especificado a lista
		 * 
		 * @param v1 Primeiro vertex.
		 * @param v2 Segundo vertex.
		 * @param v3 ultimo vertex.
		 */
		public void addTriangle(int v1, int v2, int v3) {
			triangles.add(v1);
			triangles.add(v2);
			triangles.add(v3);
		}
		
		/**
		 * Configura a entrada da coordenada da textura especificada
		 * 
		 * @param v Vertex alvo.
		 * @param tx Coordenada da textura X
		 * @param ty Coordenada da textura Y
		 */
		public void addTextureCoordinate(int v, float tx, float ty) {
			textureCoords[2*v] = tx;
			textureCoords[2*v + 1] = ty;
		}
		
		/**
		 * Carrega os buffers/texturas e limpa a informações temporárias utilizadas.
		 */
		public void load() {
			FloatBuffer textureCoordsBuf = BufferUtils.asBuffer(textureCoords);
			textureCoords = null;
			// allocate a VBO
			int[] allocatedVBO = { 0 };
			GLES20.glGenBuffers(1, allocatedVBO, 0);
			if (allocatedVBO[0] <= 0)
				throw new RuntimeException("Unable to allocate VBO!");
			this.vbo = allocatedVBO[0];
			GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, allocatedVBO[0]);
			GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, textureCoordsBuf.capacity() * 4,
					textureCoordsBuf, GLES20.GL_STATIC_DRAW);
			GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
			
			ShortBuffer vertexIndicesBuf = BufferUtils.allocateShortBuffer(triangles.size());
			for (Integer v: triangles)
				vertexIndicesBuf.put((short)((int)v));
			vertexIndicesBuf.position(0);
			indexCount = triangles.size();
			triangles = null;
			// allocate an IBO
			int[] allocatedIBO = { 0 };
			GLES20.glGenBuffers(1, allocatedIBO, 0);
			if (allocatedIBO[0] <= 0)
				throw new RuntimeException("Unable to allocate IBO!");
			ibo = allocatedIBO[0];
			GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, allocatedIBO[0]);
			GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, vertexIndicesBuf.capacity() * 2,
					vertexIndicesBuf, GLES20.GL_STATIC_DRAW);
			GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0);
			
			Object[] terrainInfo = Terrain.TERRAIN_TYPES[type];
			String textureFile = (String)terrainInfo[1];
			if (textureFile != null) {
				texture = TextureLoader.loadTextureFromAsset(TEXTURE_PATH + textureFile);
				if (texture == 0)
					throw new RuntimeException("Unable to load texture file '" + textureFile + "'!");
				
				GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
				GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST_MIPMAP_LINEAR);
				GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
				GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT);
				GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT);
			}
		}
	}
	
	/**
	 * Referência ao objeto da model do terreno
	 */
	protected Terrain terrain;
	
	/**
	 * Número total de vértices
	 */
	protected int vertexCount;
	
	/**
	 * VBO que amazena as informações do vertex
	 */
	protected int vbo;
	
	/**
	 * Diferentes pacotes que compõem o terreno
	 */
	protected TerrainParcel[] parcels;
	
	
	/**
	 * Inicializa o objeto do terreno 3D
	 * 
	 * @param scene Objeto da scene pai
	 * @param tag Tag opcional
	 * @param priority Prioridade opcional
	 */
	public Terrain3D(Scene3D scene, Terrain terrain, String tag, int priority) {
		super(scene, tag, priority);
		
		this.terrain = terrain;
		
		// get shader program
		shader = scene.getShaderManager().getShader("s3d_tex_phong");
		
		// generate the terrain from the model object's height map
		parcels = new TerrainParcel[Terrain.TERRAIN_TYPES.length];
		generateTerrain3D();
	}
	
	/**
	 * Gera os vertices, poligonos e coordenadas da textura do terreno
	 */
	protected void generateTerrain3D() {
		int[] dims = terrain.getMatrixDimensions();
		float[][] heightMap = terrain.getHeightMap();
		byte[][] typeMap = terrain.getTypeMap();
		
		vertexCount = (dims[0] * dims[1]);
		
		// COmputa o vertex e informações normais
		float[] vertexNormals = new float[vertexCount * 8];
		for (int i=0; i<dims[0]; i++) {
			for (int j=0; j<dims[1]; j++) {
				int v = (i * dims[1] + j); // the current vertex
				
				// Preenche a matriz do vertex
				vertexNormals[8*v] = i * Terrain.UNIT_SCALE; // x
				vertexNormals[8*v+1] = j * Terrain.UNIT_SCALE; // y
				vertexNormals[8*v+2] = heightMap[i][j]; // z
				
				// Computa os triangulos
				byte t = typeMap[i][j];
				if (parcels[t] == null) {
					parcels[t] = new TerrainParcel(t);
				}
				TerrainParcel parcel = parcels[t];
				
				if ((i < dims[0]-1) && (j < dims[1]-1)) {
					int v2 = ((i+1)*dims[1] + j); // bottom-left
					int v3 = ((i+1)*dims[1] + j+1); // bottom-right
					int v4 = (i*dims[1] + j+1); // top-right
					
					parcel.addTriangle(v, v2, v3);
					parcel.addTriangle(v, v3, v4);
					
					// computa as coordenadas da textura para os vertices do triangulo
					final float texScale = 0.8f;
					parcel.addTextureCoordinate(v, j*texScale, i*texScale);
					parcel.addTextureCoordinate(v2, j*texScale, (i+1f)*texScale);
					parcel.addTextureCoordinate(v3, (j+1f)*texScale, (i+1f)*texScale);
					parcel.addTextureCoordinate(v4, (j+1f)*texScale, i*texScale);
				}
			}
		}

		for (int i=0; i<dims[0]; i++) {
			for (int j = 0; j < dims[1]; j++) {
				int v = (i * dims[1] + j); // vertex atual
				
				// pode existir até 6 triangulos visinhos para o vertex atual
				float[] tmp = new float[3];
				int v1, v2, v3, v4; // os 4 vertices
				
				if (i > 0 && j > 0) {
					v1 = ((i-1)*dims[1] + j-1);
					v2 = ((i)*dims[1] + j-1);
					v3 = v;
					v4 = ((i-1)*dims[1] + j);

					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v3, vertexNormals, 8*v1, vertexNormals, 8*v2);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];

					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v3, vertexNormals, 8*v4, vertexNormals, 8*v1);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];
				}
				
				if (i > 0 && j < (dims[1]-1)) {
					v1 = ((i-1)*dims[1] + j);
					v2 = v;
					v3 = ((i)*dims[1] + j+1);
					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v2, vertexNormals, 8*v3, vertexNormals, 8*v1);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];
				}
				
				if (i < (dims[0]-1) && j > 0) {
					v1 = ((i)*dims[1] + j-1);
					v3 = ((i+1)*dims[1] + j);
					v4 = v;
					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v4, vertexNormals, 8*v1, vertexNormals, 8*v3);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];
				}
				
				if (i < (dims[0]-1) && j < (dims[1]-1)) {
					v1 = v;
					v2 = ((i+1)*dims[1] + j);
					v3 = ((i+1)*dims[1] + j+1);
					v4 = ((i)*dims[1] + j+1);

					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v1, vertexNormals, 8*v2, vertexNormals, 8*v3);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];

					NormalUtils.computeNormal(tmp, 0, vertexNormals, 8*v1, vertexNormals, 8*v3, vertexNormals, 8*v4);
					vertexNormals[8*v+4] += tmp[0];
					vertexNormals[8*v+5] += tmp[1];
					vertexNormals[8*v+6] += tmp[2];
				}

				NormalUtils.normalize(vertexNormals, 8*v+4);
			}
		}
		
		// Gera as VBOs
		FloatBuffer vertexNormalBuf = BufferUtils.asBuffer(vertexNormals);
		vertexNormalBuf.position(0);
		int[] allocatedVBO = { 0 };
		GLES20.glGenBuffers(1, allocatedVBO, 0);
		if (allocatedVBO[0] <= 0)
			throw new RuntimeException("Unable to allocate VBO!");
		vbo = allocatedVBO[0];
		GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
		GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vertexNormalBuf.capacity() * 4,
				vertexNormalBuf, GLES20.GL_STATIC_DRAW);
		GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
		
		// carrega a informação gerada
		for (TerrainParcel parcel : parcels) {
			if (parcel != null) {
				parcel.load();
			}
		}
	}
	
	
	@Override
	public void draw() {
		Matrix.setIdentityM(modelMatrix, 0);
		
		final float[] lightPosition = GameScene.LIGHT_POSITION;
		final float[] ambientColor = new float[] { 0.3f, 0.3f, 0.3f } ;
		final float[] diffuseColor = new float[] { 1.0f, 1.0f, 1.0f } ;
		final float[] specularColor = new float[] { 0.5f, 0.5f, 0.5f } ;
		
		float[] normalMatrix = scene.getCamera().computeNormalMatrix(modelMatrix);
		
		shader.use();
		
		// pega a localização dos atributos de sombreamento
		int a_position = shader.getAttribLocation("a_position");
		int a_normal = shader.getAttribLocation("a_normal");
		int a_textureCoords = shader.getAttribLocation("a_textureCoords");
		
		// pega a localização dos uniformes de sombreamento
		int u_normalMatrix = shader.getUniformLocation("u_normalMatrix");
		int u_modelMatrix = shader.getUniformLocation("u_modelMatrix");
		int u_lightPos = shader.getUniformLocation("u_lightPos");
		
		int u_texture = shader.getUniformLocation("u_texture");
		int u_textureEnable = shader.getUniformLocation("u_textureEnable");
		
		int u_ambientColor = shader.getUniformLocation("u_ambientColor");
		int u_diffuseColor = shader.getUniformLocation("u_diffuseColor");
		int u_specularColor = shader.getUniformLocation("u_specularColor");
		int u_alpha = shader.getUniformLocation("u_alpha");
		int u_shininess = shader.getUniformLocation("u_shininess");
		
		// envia as matrizes
		GLES20.glUniformMatrix4fv(u_modelMatrix, 1, false, modelMatrix, 0);
		GLES20.glUniformMatrix4fv(u_normalMatrix, 1, false, normalMatrix, 0);
		
		// envia a informação do vertex para o sombreamento
		GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
		GLES20.glVertexAttribPointer(a_position, 3 /* coords */, GLES20.GL_FLOAT, false,
				4 * 4 * 2 /* bytes */, 0);
		GLES20.glVertexAttribPointer(a_normal, 3 /* coords */, GLES20.GL_FLOAT, false,
				4 * 4 * 2 /* bytes */, 4 * 4);
		GLES20.glEnableVertexAttribArray(a_position);
		GLES20.glEnableVertexAttribArray(a_normal);
		GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
		
		GLES20.glUniform3fv(u_lightPos, 1, lightPosition, 0);
		
		for (TerrainParcel parcel: parcels) {
			if (parcel == null) continue;
			
			if (parcel.texture > 0) {
				GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, parcel.vbo);
				GLES20.glVertexAttribPointer(a_textureCoords, 2, GLES20.GL_FLOAT, false,
						0 /* bytes */, 0);
				GLES20.glEnableVertexAttribArray(a_textureCoords);
				GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
				
				GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
				GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, parcel.texture);
				GLES20.glUniform1i(u_texture, 0);
				GLES20.glUniform1i(u_textureEnable, 1);
				
			} else {
				// desativa a textura
				GLES20.glUniform1i(u_textureEnable, 0);
			}
			
			// configura as cores e texturas
			GLES20.glUniform3fv(u_ambientColor, 1, ambientColor, 0);
			GLES20.glUniform3fv(u_diffuseColor, 1, diffuseColor, 0);
			GLES20.glUniform3fv(u_specularColor, 1, specularColor, 0);
			GLES20.glUniform1f(u_alpha, 1.0f);
			GLES20.glUniform1f(u_shininess, 8.0f);
			
			// Desenha!
			GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, parcel.ibo);
			GLES20.glDrawElements(GLES20.GL_TRIANGLES, parcel.indexCount, GLES20.GL_UNSIGNED_SHORT, 0);
			GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
	}
	
}
