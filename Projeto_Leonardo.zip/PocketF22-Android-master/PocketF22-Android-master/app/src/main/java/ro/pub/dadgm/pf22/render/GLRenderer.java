package ro.pub.dadgm.pf22.render;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Implementa a interface {android.opengl.GLSurfaceView.Renderer}.
 */
public class GLRenderer implements GLSurfaceView.Renderer {
	
	/**
	 * Identifica se a superficie GL foi inicializada
	 */
	protected boolean surfaceCreated = false;
	
	/**
	 * A view atual que precisa ser exibida
	 */
	protected ShaderManager.View currentView = null;
	
	/**
	 * A altura e largura atual da viewport
	 */
	protected int width = -1, height;
	
	
	/**
	 * Construtor padrão
	 */
	public GLRenderer() {

	}
	
	
	/**
	 * Altera a view atualChanges the current view.
	 * 
	 * Deve ser chamado da thread OpenGL
	 */
	public void setView(ShaderManager.View view) {
		if (currentView != null) {
			currentView.onClose();
		}
		currentView = view;
		
		if (surfaceCreated) {
			view.onActivate();
		}
		if (width != -1) {
			view.onResize(width, height);
		}
	}
	
	@Override
	public void onSurfaceCreated(GL10 unused, EGLConfig config) {
		// Configura a cor do frame do fundo
		GLES20.glClearColor(0.34f, 0.8f, 0.9f, 1.0f);
		
		GLES20.glEnable(GLES20.GL_DEPTH_TEST);
		GLES20.glDepthFunc(GLES20.GL_LEQUAL);
		GLES20.glClearDepthf(1.0f);
		
		GLES20.glEnable(GLES20.GL_CULL_FACE);
		GLES20.glCullFace(GLES20.GL_BACK);
		
		GLES20.glEnable(GLES20.GL_BLEND);
		GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);
		
		surfaceCreated = true;
		
		if (currentView != null)
			currentView.onActivate();
	}
	
	@Override
	public void onSurfaceChanged(GL10 unused, int width, int height) {
		this.width = width;
		this.height = height;
		if (currentView != null) {
			currentView.onResize(width, height);
		}
	}
	
	@Override
	public void onDrawFrame(GL10 unused) {
		// desenha o fundo
		GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
		
		if (currentView != null) {
			currentView.draw();
		}
	}
}
