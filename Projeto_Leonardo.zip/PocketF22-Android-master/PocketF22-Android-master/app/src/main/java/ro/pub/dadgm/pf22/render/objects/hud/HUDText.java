package ro.pub.dadgm.pf22.render.objects.hud;

import ro.pub.dadgm.pf22.render.Scene3D;
import ro.pub.dadgm.pf22.render.utils.DrawText;

/**
 * Draws a simple HUD text (centered).
 */
public class HUDText extends HUDObject {
	
	/**
	 * Instancia da DrawText
	 */
	protected DrawText drawText;
	
	/**
	 * Text HUD para desenhar
	 */
	protected String text;
	
	
	/**
	 * Inicializa o objeto do fundo do menu
	 */
	public HUDText(Scene3D scene, String tag, int priority, String text) {
		super(scene, tag, priority);
		
		this.drawText = scene.getDrawText();
		
		// dimensões padrão
		height = 0.5f;
		
		setCaption(text);
	}
	
	
	@Override
	public void draw() {
		if (!visibility) return;
		
		prepareDrawText();
		drawText.drawText(text);
	}
	
	/**
	 * Altera a legenda do item HUD
	 */
	public void setCaption(String caption) {
		this.text = caption;
		
		prepareDrawText();
		width = drawText.calculateDrawWidth(caption) * drawText.getModelScale();
	}
	
	/**
	 * Prepara a instancia DrawText para desenhar o texto
	 */
	protected void prepareDrawText() {
		float fHeight = height;
		
		drawText.reset();
		drawText.useFont("fonts/Roboto-Regular.ttf", 48);
		
		drawText.setStartPosition(position.getX() + width / 2, position.getY(), position.getZ());
		drawText.setScale(fHeight);
		drawText.setAlignment(DrawText.FontAlign.ALIGN_CENTER);
	}
	
}
