package ro.pub.dadgm.pf22.game.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import ro.pub.dadgm.pf22.physics.CollisionObject;
import ro.pub.dadgm.pf22.physics.MobileObject;
import ro.pub.dadgm.pf22.utils.events.CollectionListener;

/**
 * Define o modelo do mundo do jogo.
 * 
 * O mundo é uma caixa com as dimensões {#WORLD_WIDTH_X} x {#WORLD_WIDTH_Y}.
 *
 * Esta classe atua como um container de outros objetos e os gerencia.
 */
public class World extends BaseModel {

	/**
	 * Espaço horizintal do jogo(X e Y).
	 */
	public static float WORLD_WIDTH_X = 50 * Terrain.UNIT_SCALE;
	public static float WORLD_WIDTH_Y = 50 * Terrain.UNIT_SCALE;
	
	/**
	 * Altura máxima do jogo.
	 */
	public static float WORLD_MAX_HEIGHT = 50.0f;
	
	
	// Componentes do mundo

	/**
	 * Define o objeto de terreno.
	 */
	protected Terrain terrain;
	
	/**
	 * Objeto do avião do jogador.
	 */
	protected PrimaryPlane player;
	
	/**
	 * Aviões inimigos sendo exibidos na tela.
	 */
	protected final IdentityHashMap<EnemyPlane, EnemyPlane> enemyPlanes;
	
	/**
	 * Lista os projéteis presentes atualmente.
	 */
	protected final IdentityHashMap<Projectile, Projectile> projectiles;
	
	/**
	 * Mantém a quantidade de objetos. Utilizado pelo motor Physics.
	 */
	protected final Set<MobileObject> mobileObjects;
	
	/**
	 * mantém a quantidade de objetos que possam colidir. Utilizado pelo motor Physics.
	 */
	protected final Set<CollisionObject> collidableObjects;

	
	/**
	 * Usado para permitir a escuta da mudança de coleção de aviões inimigos
	 */
	protected transient final List<CollectionListener<EnemyPlane>> enemyCollectionListeners;
	
	/**
	 * Usado para permitir a escuta da mudança de coleção de projéteis
	 */
	protected transient final List<CollectionListener<Projectile>> projectileCollectionListeners;
	
	
	/**
	 * Construtor do objeto.
	 */
	public World() {
		// Gera o terreno
		terrain = new Terrain((int)Math.ceil(WORLD_WIDTH_X / Terrain.UNIT_SCALE),
				(int)Math.ceil(WORLD_WIDTH_Y / Terrain.UNIT_SCALE), 
				WORLD_MAX_HEIGHT * 0.5f);
		
		player = new PrimaryPlane();
		
		// Inicializa as estruturas
		enemyPlanes = new IdentityHashMap<>();
		projectiles = new IdentityHashMap<>();
		enemyCollectionListeners = new ArrayList<>();
		projectileCollectionListeners = new ArrayList<>();
		
				mobileObjects = Collections.newSetFromMap(
				new ConcurrentHashMap<MobileObject, Boolean>());
		collidableObjects = Collections.newSetFromMap(
				new ConcurrentHashMap<CollisionObject, Boolean>());
		
		// Adiciona osobjetos fixos para a simulação do Physics
		mobileObjects.add(player);
		collidableObjects.add(terrain);
		collidableObjects.add(player);
	}
	
	
	/**
	 * Retorna o objeto do terreno do mundo
	 */
	public synchronized Terrain getTerrain() {
		return terrain;
	}
	
	/**
	 * Retorna o objeto do avião do jogador
	 */
	public synchronized PrimaryPlane getPlayer() {
		return player;
	}
	
	/**
	 * Retorna o conjunto dinâmico dos objetos moveis
	 */
	public Set<MobileObject> getMobileObjects() {
		return Collections.unmodifiableSet(mobileObjects);
	}
	
	/**
	 * Retorna o conjunto dinãmico de objetos colisiveis
	 */
	public Set<CollisionObject> getCollidableObjects() {
		return Collections.unmodifiableSet(collidableObjects);
	}
	
	/**
	 * Adiciona um novo listener à coleção de novos aviões inimigos
	 */
	public void addEnemyCollectionListener(CollectionListener<EnemyPlane> listener) {
		enemyCollectionListeners.add(listener);
	}
	
	/**
	 * Adiciona um novo listener à coleção de novo projéteis
	 */
	public void addProjectileCollectionListener(CollectionListener<Projectile> listener) {
		projectileCollectionListeners.add(listener);
	}
	
	/**
	 * retorna uma lista de aviões inimigosemy planes.
	 */
	public synchronized EnemyPlane[] getEnemyPlanes() {
		return enemyPlanes.values().toArray(new EnemyPlane[enemyPlanes.size()]);
	}
	
	/**
	 * Retorna um lista de Projéteis
	 */
	public synchronized Projectile[] getProjectiles() {
		return projectiles.values().toArray(new Projectile[projectiles.size()]);
	}
	
	
	/**
	 * Adiciona um avião inimigo ao mundo
	 */
	public synchronized void addPlane(EnemyPlane plane) {
		enemyPlanes.put(plane, plane);
		collidableObjects.add(plane);
		mobileObjects.add(plane);
		
		for (CollectionListener<EnemyPlane> listener: enemyCollectionListeners) {
			listener.onObjectAdded(plane);
		}
	}
	
	/**
	 * Deleta o avião inimigo especificado do mundo
	 */
	public synchronized void removePlane(EnemyPlane plane) {
		enemyPlanes.remove(plane);
		collidableObjects.remove(plane);
		mobileObjects.remove(plane);
		
		for (CollectionListener<EnemyPlane> listener: enemyCollectionListeners) {
			listener.onObjectRemoved(plane);
		}
	}
	
	/**
	 * Adiciona projéteis ao mundo
	 */
	public synchronized void addProjectile(Projectile projectile) {
		projectiles.put(projectile, projectile);
		collidableObjects.add(projectile);
		mobileObjects.add(projectile);
		
		for (CollectionListener<Projectile> listener: projectileCollectionListeners) {
			listener.onObjectAdded(projectile);
		}
	}
	
	/**
	 * Deleta o projétil especificado do mundo
	 */
	public synchronized void removeProjectile(Projectile projectile) {
		projectiles.remove(projectile);
		collidableObjects.remove(projectile);
		mobileObjects.remove(projectile);
		
		for (CollectionListener<Projectile> listener: projectileCollectionListeners) {
			listener.onObjectAdded(projectile);
		}
	}
	
}
