package com.leonardoDeus.leonardoDeus;

import com.leonardoDeus.leonardoDeus.AndGraph.AGGameManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGInputManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScene;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScreenManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSprite;



public class CenaMenu extends AGScene {

    AGSprite imagemfundo = null;
    AGSprite vrIniciar = null;
    AGSprite vrOpcoes = null;
    AGSprite vrSair = null;
    AGSprite vrSobre = null;



    int estado = 0;
    //int som = 0;
    int somChew = 0;


    public CenaMenu(AGGameManager manager) {
        super(manager);
    }

    @Override
    public void init() {

        imagemfundo = createSprite(R.drawable.fundo, 1, 1); // carregar imagem
        imagemfundo.setScreenPercent(100, 100); // percentual imagem ocupa na tela
        imagemfundo.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight / 2); // percentual que a imagem vai ocupar na tela

        this.setSceneBackgroundColor(1, 0, 0);

        vrIniciar = this.createSprite(R.drawable.jogar, 1, 1);
        vrIniciar.setScreenPercent(50, 10);
        vrIniciar.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight / 1.4f);
        vrIniciar.fadeIn(3000);

        vrOpcoes = this.createSprite(R.drawable.opcoes, 1, 1);
        vrOpcoes.setScreenPercent(50, 10);
        vrOpcoes.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight / 1.7f);
        vrOpcoes.fadeIn(3000);

        vrSair = this.createSprite(R.drawable.sair, 1, 1);
        vrSair.setScreenPercent(50, 10);
        vrSair.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight /2.2f);
        vrSair.fadeIn(3000);

        vrSobre = this.createSprite(R.drawable.sobremenu, 1, 1);
        vrSobre.setScreenPercent(50, 10);
        vrSobre.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight /3);
        vrSobre.fadeIn(3000);



       // if (Config.som)
       // Config.tocarMusica(new Random().nextInt(2));

    }

    @Override
    public void restart() {

    }

    @Override
    public void stop() {


    }

    @Override
    public void loop() {
        if (AGInputManager.vrTouchEvents.backButtonClicked()) {

            vrGameManager.setCurrentScene(0);
            return;

        }
        if (AGInputManager.vrTouchEvents.screenClicked())
        {
            if (vrIniciar.collide(AGInputManager.vrTouchEvents.getLastPosition())) {

                vrGameManager.setCurrentScene(2);
                return;
            }

            if (vrOpcoes.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                vrGameManager.setCurrentScene(3);
                return;
            }

            if (vrSobre.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                vrGameManager.setCurrentScene(5);
                return;
            }


            if (vrSair.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                System.exit(0);
                return;
            }

            }

        }
    }





