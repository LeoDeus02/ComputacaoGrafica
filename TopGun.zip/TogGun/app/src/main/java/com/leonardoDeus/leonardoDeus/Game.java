package com.leonardoDeus.leonardoDeus;

import android.os.Bundle;

import com.leonardoDeus.leonardoDeus.AndGraph.AGActivityGame;
import com.leonardoDeus.leonardoDeus.AndGraph.AGGameManager;

public class Game extends AGActivityGame {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // objeto manager
        vrManager = new AGGameManager(this, true);

        //instancia das cenas graficas
        CenaAbertura abertura = new CenaAbertura(vrManager); //  cena  abertura
        CenaMenu menu = new CenaMenu(vrManager);   //  cena do menu
        CenaGame game = new CenaGame(vrManager);   //  cena game
        CenaConfiguracao configuracao = new CenaConfiguracao(vrManager);  // cena config
        CenaGameOver cenaGameOver = new CenaGameOver(vrManager); //  game Over
        CenaSobre cenaSobre = new CenaSobre (vrManager); //  sobre

//adicionando as cenas
        vrManager.addScene(abertura); // 0 ==> primeira
        vrManager.addScene(menu);    //  1 ==> segunda
        vrManager.addScene(game);   // 2 ==> terceira
        vrManager.addScene(configuracao); //3 ==> quarta
        vrManager.addScene(cenaGameOver); //4 ==> quinta
        vrManager.addScene(cenaSobre); //5 ==> quinta
    }
}
