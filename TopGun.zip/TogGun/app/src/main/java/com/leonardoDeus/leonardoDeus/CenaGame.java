package com.leonardoDeus.leonardoDeus;

import com.leonardoDeus.leonardoDeus.AndGraph.AGGameManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGInputManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScene;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScreenManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSoundManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSprite;
import com.leonardoDeus.leonardoDeus.AndGraph.AGTimer;
import com.leonardoDeus.leonardoDeus.AndGraph.AGVector2D;

import java.util.ArrayList;
import java.util.Random;


public class CenaGame extends AGScene {
    private ArrayList<AGSprite> arrayMisseis = null;
    private ArrayList<AGSprite> arrayTiros = null;
    private ArrayList<AGSprite> arrayExplosoes = null;
    private AGSprite aviaoPrincipal = null;
    private AGSprite superExplosao = null;
    private AGSprite[] imagemFundo = null;

    private int somExplosao = 0;             // variavel para o som de explosao das aviaos inimigas
    private int somExplosaoPrincipal = 0;   // varivael para o som de explosao da aviao  principal
    private Random sorteiaPosicao = null;

    private AGSprite[] placar = null;
    private AGTimer tempoAviao = null;
    private int numeroColisoes = 0;
    private AGTimer tempoGameOver = null;
    private int iAux = 0; //variavel para score

    public CenaGame(AGGameManager manager) {
        super(manager);
    }

    @Override
    public void init() {
        this.setSceneBackgroundColor(0, 0, 0);
        this.arrayMisseis = new ArrayList<>();
        this.arrayTiros = new ArrayList<>();
        this.arrayExplosoes = new ArrayList<>();
        this.superExplosao = null;
        this.sorteiaPosicao = new Random(AGScreenManager.iScreenWidth);
        this.imagemFundo = new AGSprite[2];

        tempoAviao = new AGTimer(2000);
        numeroColisoes = 0;


        imagemFundo[0] = this.createSprite(R.drawable.branco, 1, 1);
        imagemFundo[0].setScreenPercent(110, 110);
        imagemFundo[0].vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight / 2);


        imagemFundo[1] = this.createSprite(R.drawable.branco, 1, 1);
        imagemFundo[1].setScreenPercent(110, 110);
        imagemFundo[1].vrPosition.setXY(AGScreenManager.iScreenWidth / 2, imagemFundo[0].getSpriteHeight() + imagemFundo[0].vrPosition.getY());

        //aviao principal (aviao)
        aviaoPrincipal = this.createSprite(R.drawable.caca2, 1, 1);
        aviaoPrincipal.setScreenPercent(30, 20);
        aviaoPrincipal.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, (aviaoPrincipal.getSpriteHeight() / 2));
        aviaoPrincipal.bAutoRender = false;


        //carregando imagen na memoria
        createSprite(R.drawable.explosion, 9, 9).bVisible = false;   // sprite de explosões
        createSprite(R.drawable.missil, 1, 1).bVisible = false;       // imagem tiro da aviao principal (aviao principal)
        createSprite(R.drawable.missil1, 1, 1).bVisible = false;


        //instancia o placar
        placar = new AGSprite[3];
        for (int i = 2; i >= 0; i--) {
            placar[i] = createSprite(R.drawable.fonte, 4, 4);
            placar[i].setScreenPercent(10, 10);
            placar[i].bAutoRender = false;


            for (int quadro = 0; quadro < 10; quadro++) {
                placar[i].addAnimation(1, true, quadro);
            }
        }
        placar[0].vrPosition.setXY(AGScreenManager.iScreenWidth - placar[0].getSpriteWidth() / 3,
                AGScreenManager.iScreenHeight - placar[0].getSpriteHeight() / 2.5f);//primeira posicao do placar
        placar[1].vrPosition.setXY(placar[0].vrPosition.getX() - placar[1].getSpriteWidth() / 2.5f,
                AGScreenManager.iScreenHeight - placar[0].getSpriteHeight() / 2.5f);//segunda posicao do placar
        placar[2].vrPosition.setXY(placar[1].vrPosition.getX() - placar[1].getSpriteWidth() / 2.5f,
                AGScreenManager.iScreenHeight - placar[0].getSpriteHeight() / 2.5f);//segunda posicao do placar

        placar[0].setCurrentAnimation(0);
        placar[1].setCurrentAnimation(0);
        placar[2].setCurrentAnimation(0);

        if (Config.som) {
            Config.tocarMusica(new Random().nextInt(2));
        }
        this.somExplosao = AGSoundManager.vrSoundEffects.loadSoundEffect("explosao.mp3");
        this.somExplosaoPrincipal = AGSoundManager.vrSoundEffects.loadSoundEffect("explosao2.mp3"); // aviao principal


    }

    //render do placar
    public void render() {
        super.render();
        placar[0].render();
        placar[1].render();
        placar[2].render();
        aviaoPrincipal.render();
    }

    @Override
    public void restart() {

    }

    @Override
    public void stop() {

    }


    @Override
    public void loop() {

        atualizaFundo();

        //movimento do aviao
        if (aviaoPrincipal.vrPosition.getX() < (AGScreenManager.iScreenWidth - aviaoPrincipal.getSpriteWidth() / 2) && AGInputManager.vrAccelerometer.getAccelX() > 2) {
            aviaoPrincipal.vrPosition.setX(aviaoPrincipal.vrPosition.getX() + 25);

        } else if (aviaoPrincipal.vrPosition.getX() > aviaoPrincipal.getSpriteWidth() / 2 && AGInputManager.vrAccelerometer.getAccelX() < -2) {
            aviaoPrincipal.vrPosition.setX(aviaoPrincipal.vrPosition.getX() - 25);


        }


        if (superExplosao != null && superExplosao.getCurrentAnimation().isAnimationEnded()) {
            if (Config.som) {
                Config.tocarMusica(new Random().nextInt(2));
            }

            vrGameManager.setCurrentScene(4);
            return;
        }

        atualizaTiro();
        atualizaaviao();
        dificuldade();
        colide();
        atualizaPlacar();
        atualizaExplosao();
        colideaviaoMae();

        if (AGInputManager.vrTouchEvents.backButtonClicked()) {

            if (Config.som) {
                Config.tocarMusica(new Random().nextInt(2));
            }

            vrGameManager.setCurrentScene(1);
            return;
        }


        if (AGInputManager.vrTouchEvents.screenClicked() && aviaoPrincipal.bVisible) {

            criaTiro();
        }


    }

    // tiros
    public void criaTiro() {

        for (AGSprite reciclado : arrayTiros) {

            if (reciclado.bRecycled) {
                reciclado.vrPosition.setXY(aviaoPrincipal.vrPosition.getX(), aviaoPrincipal.getSpriteHeight());
                reciclado.bRecycled = false;
                reciclado.bVisible = true;
                if (Config.som) {
                    AGSoundManager.vrSoundEffects.play(somExplosao);
                }
                return;
            }
        }

        AGSprite tiro = null;
        tiro = createSprite(R.drawable.missil, 2, 4);
        tiro.setScreenPercent(8, 5);
        tiro.vrPosition.setXY(aviaoPrincipal.vrPosition.getX(), aviaoPrincipal.getSpriteHeight());


        arrayTiros.add(tiro);
    }

    public void atualizaTiro() {

        for (AGSprite tiro : arrayTiros) {
            tiro.vrPosition.setY(tiro.vrPosition.getY() + 20);


            //reciclagem do tiro
            if (tiro.vrPosition.getY() > AGScreenManager.iScreenHeight + tiro.getSpriteHeight()) {
                tiro.bRecycled = true;
                tiro.bVisible = false;
            }
        }
    }

    //atualiza imagem principal do fundo do jogo
    public void atualizaFundo() {

        this.imagemFundo[0].vrPosition.setY(imagemFundo[0].vrPosition.getY() - 17);
        this.imagemFundo[1].vrPosition.setY(imagemFundo[1].vrPosition.getY() - 17);


        if (imagemFundo[0].vrPosition.getY() + (imagemFundo[0].getSpriteHeight() / 2) < 0) {
            this.imagemFundo[0].vrPosition.setY((imagemFundo[0].getSpriteHeight() / 2) + AGScreenManager.iScreenHeight);
        }
        if (imagemFundo[1].vrPosition.getY() + (imagemFundo[1].getSpriteHeight() / 2) < 0) {
            this.imagemFundo[1].vrPosition.setY((imagemFundo[1].getSpriteHeight() / 2) + AGScreenManager.iScreenHeight);
        }
    }


    // MISSEIS 
    public void criaMisseis() {

        for (AGSprite reciclado : arrayMisseis) {
            if (reciclado.bRecycled) {
                reciclado.vrPosition.setXY((reciclado.getSpriteWidth() / 2) + sorteiaPosicao.nextInt((int) (AGScreenManager.iScreenWidth - reciclado.getSpriteWidth())), AGScreenManager.iScreenHeight + reciclado.getSpriteHeight());
                reciclado.bRecycled = false;
                reciclado.bVisible = true;
                return;
            }
        }
        AGSprite aviao = null;
        aviao = createSprite(R.drawable.missil1, 8, 4);
        aviao.iMirror=AGSprite.VERTICAL_HORIZONTAL;
        aviao.setScreenPercent(22, 15);
        aviao.vrPosition.setXY((aviao.getSpriteWidth() / 2) + sorteiaPosicao.nextInt((int) (AGScreenManager.iScreenWidth - aviao.getSpriteWidth())), AGScreenManager.iScreenHeight + aviao.getSpriteHeight());

        arrayMisseis.add(aviao);

    }

    public void atualizaaviao() {

        for (AGSprite aviao : arrayMisseis) {
            aviao.vrPosition.setY(aviao.vrPosition.getY() - 15);

            //reciclagem da aviao
            if (aviao.vrPosition.getY() < -(aviao.getSpriteHeight() / 2)) {
                aviao.bRecycled = true;
                aviao.bVisible = false;
            }
        }
    }

    public void colideaviaoMae() {
        for (AGSprite aviao : arrayMisseis) {

            if (!aviao.bRecycled && aviaoPrincipal.collide(aviao) && aviaoPrincipal.bVisible) {
                if (Config.som) {
                    AGSoundManager.vrSoundEffects.play(somExplosaoPrincipal);
                }
                criaSuperExplosao();

            }

        }
    }
//colisao & explosao

    public void colide() {

        for (AGSprite aviao : arrayMisseis) {

            if (!aviao.bRecycled) {
                for (AGSprite tiro : arrayTiros) {

                    if (!tiro.bRecycled && aviao.collide(tiro.vrPosition)) {
                        aviao.bRecycled = true;
                        aviao.bVisible = false;

                        tiro.bRecycled = true;
                        tiro.bVisible = false;
                        criaExplosao(aviao.vrPosition);
                        if (Config.som) {
                            AGSoundManager.vrSoundEffects.play(somExplosao);
                        }

                        numeroColisoes++;

                    }
                }

            }

        }
    }

    public void criaExplosao(AGVector2D posicao) {


        for (AGSprite reciclado : arrayExplosoes) {

            if (reciclado.bRecycled) {
                reciclado.vrPosition.setXY(posicao.getX(), posicao.getY());
                reciclado.bRecycled = false;
                reciclado.bVisible = true;
                reciclado.getCurrentAnimation().restart();
                return;
            }
        }
        AGSprite exposao = null;
        exposao = createSprite(R.drawable.explosion, 9, 9);
        exposao.addAnimation(100, false, 0, 72);
        exposao.setScreenPercent(20, 10);
        exposao.vrPosition.setXY(posicao.getX(), posicao.getY());
        arrayExplosoes.add(exposao);

    }

    public void atualizaExplosao() {

        for (AGSprite explosao : arrayExplosoes) {

            //quando a aviao sumir, ele será reciclada
            if (explosao.getCurrentAnimation().isAnimationEnded()) {
                explosao.bRecycled = true;
                explosao.bVisible = false;
            }
        }
    }

    //placar

    public void atualizaPlacar() {

        if (numeroColisoes < 100) {
            placar[1].setCurrentAnimation(numeroColisoes / 10);
            placar[0].setCurrentAnimation(numeroColisoes % 10);
        } else {
            placar[2].setCurrentAnimation(Integer.parseInt(String.valueOf(numeroColisoes).substring(0, 1)));
            placar[1].setCurrentAnimation(Integer.parseInt(String.valueOf(numeroColisoes).substring(1, 2)));
            placar[0].setCurrentAnimation(Integer.parseInt(String.valueOf(numeroColisoes).substring(2, 3)));
        }
    }

    public void criaSuperExplosao() {
        superExplosao = createSprite(R.drawable.explosion, 9, 9); //sprite da explosão principal
        superExplosao.addAnimation(100, false, 0, 80);
        superExplosao.setScreenPercent(20, 10);
        superExplosao.vrPosition.setXY(aviaoPrincipal.vrPosition.getX(), aviaoPrincipal.vrPosition.getY());

        aviaoPrincipal.bVisible = false;


    }

    //######################  DIFICULDADES ########################

    public void dificuldade() {
        tempoAviao.update();
        if (tempoAviao.isTimeEnded()) {
            criaMisseis();

            if (numeroColisoes <= 15) {
                tempoAviao.restart(2000);//2000


            } else if (numeroColisoes <= 25) {
                tempoAviao.restart(1750);//1750


            } else if (numeroColisoes <= 35) {
                tempoAviao.restart(1500);//1500

            } else if (numeroColisoes <= 45) {
                tempoAviao.restart(1250);//1250

            } else if (numeroColisoes <= 55) {
                tempoAviao.restart(900);//900

            } else if (numeroColisoes <= 70) {
                tempoAviao.restart(500);//500

            } else {
                tempoAviao.restart();

            }

        }
    }


}

