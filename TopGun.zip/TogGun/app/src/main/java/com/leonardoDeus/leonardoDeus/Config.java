package com.leonardoDeus.leonardoDeus;

import com.leonardoDeus.leonardoDeus.AndGraph.AGSoundManager;



public abstract class Config
{
    public static boolean som = true;

    public static void tocarMusica(int musica){
        AGSoundManager.vrMusic.stop();
        switch (musica){
            case 0:
                AGSoundManager.vrMusic.loadMusic("zone.mp3", true);
               AGSoundManager.vrMusic.play();
                return;
            case 1:
                AGSoundManager.vrMusic.loadMusic("topgun.mp3", true);
               AGSoundManager.vrMusic.play();
                return;
            case 2: AGSoundManager.vrMusic.loadMusic("ramones.mp3", true);
                AGSoundManager.vrMusic.play();
                return;

        }
    }

}
