package com.leonardoDeus.leonardoDeus;

import com.leonardoDeus.leonardoDeus.AndGraph.AGGameManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGInputManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScene;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScreenManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSoundManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSprite;

import java.util.Random;


public class CenaConfiguracao extends AGScene{
    AGSprite imagemfundo = null;
    AGSprite som = null;

    public CenaConfiguracao(AGGameManager manager) { super(manager);}

    @Override
    public void init()
    {
        this.imagemfundo = this.createSprite(R.drawable.fundo, 1, 1);
        imagemfundo.setScreenPercent(100, 100);
        imagemfundo.vrPosition.setXY(AGScreenManager.iScreenWidth/2, AGScreenManager.iScreenHeight/2);



        if(Config.som){
            this.som = this.createSprite(R.drawable.off,1,1);
        }
        else{
            this.som = this.createSprite(R.drawable.som,1,1);
        }

        this.som.setScreenPercent(30,15);
        this.som.vrPosition.setXY(AGScreenManager.iScreenWidth/2, AGScreenManager.iScreenHeight/2);
        this.som.fadeIn(3000);

    }

    @Override
    public void restart() {

    }
    public void render() {
        super.render();

    }

    @Override
    public void stop() {

    }

    @Override
    public void loop()
    {


        if(AGInputManager.vrTouchEvents.backButtonClicked())
        {
            vrGameManager.setCurrentScene(1);
            return;
        }

        if(AGInputManager.vrTouchEvents.screenClicked()){

            if(this.som.collide(AGInputManager.vrTouchEvents.getLastPosition())){

                if(Config.som){
                    AGSoundManager.vrMusic.stop();

                    Config.som = false;
                }

                else {

                    Config.som = true;
                    Config.tocarMusica(new Random().nextInt(3));
                }

                vrGameManager.setCurrentScene(1);

            }

        }

    }

    }

