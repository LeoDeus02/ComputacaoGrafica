package com.leonardoDeus.leonardoDeus;

import com.leonardoDeus.leonardoDeus.AndGraph.AGGameManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGInputManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScene;
import com.leonardoDeus.leonardoDeus.AndGraph.AGScreenManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSoundManager;
import com.leonardoDeus.leonardoDeus.AndGraph.AGSprite;

import java.util.Random;



public class CenaSobre extends AGScene
{
    AGSprite imagemsobre = null;


    public CenaSobre(AGGameManager manager )
    {
        super(manager);
    }

    @Override
    public void init()
    {
        this.imagemsobre = this.createSprite(R.drawable.sobre, 1, 1);
        imagemsobre.setScreenPercent(100, 100); // percentual imagem ocupa na tela
        imagemsobre.vrPosition.setXY(AGScreenManager.iScreenWidth / 2, AGScreenManager.iScreenHeight / 2); // percentual que a imagem vai ocupar na tela

        setSceneBackgroundColor(1,1,1);
        Config.tocarMusica(new Random().nextInt(3));
        AGSoundManager.vrMusic.play();


    }

    @Override
    public void restart() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void loop() {

        if (AGInputManager.vrTouchEvents.backButtonClicked()) {
            AGSoundManager.vrMusic.stop();
            if (Config.som) {
                Config.tocarMusica(new Random().nextInt(3));
            }
            vrGameManager.setCurrentScene(1);
            return;
        }
    }

}